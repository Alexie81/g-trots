<?php
/**
 * G-Trots CRM - REST API
 *
 * Incarca acest fisier pe server la:
 *   https://cab-it.ro/trotty-api/api.php
 *
 * schema.sql poate fi rulat automat din desktop, din Settings.
 */

// ─── Configuratie ──────────────────────────────────────────────────────────────

define('SERVER_CONFIG_FILE', __DIR__ . '/api_config.local.php');

function loadServerRuntimeConfig(): array {
    if (!is_file(SERVER_CONFIG_FILE)) {
        return [];
    }
    $config = include SERVER_CONFIG_FILE;
    return is_array($config) ? $config : [];
}

$runtimeConfig = loadServerRuntimeConfig();

define('API_KEY', $runtimeConfig['api_key'] ?? 'GTROTS_X9K3M7_2026_SECURE');
define('DB_HOST', $runtimeConfig['db_host'] ?? 'localhost');
define('DB_NAME', $runtimeConfig['db_name'] ?? 'cabitro_mobile_trotty_clients');
define('DB_USER', $runtimeConfig['db_user'] ?? 'cabitro_admin');
define('DB_PASS', $runtimeConfig['db_pass'] ?? 'Alexie1981*#');
define('DEFAULT_ADMIN_USER', 'admin');
define('DEFAULT_ADMIN_PASS', 'admin');
define('DEFAULT_ADMIN_NAME', 'Administrator');
define('WHATSAPP_GRAPH_VERSION', getenv('WHATSAPP_GRAPH_VERSION') ?: 'v23.0');
define('WHATSAPP_PHONE_NUMBER_ID', getenv('WHATSAPP_PHONE_NUMBER_ID') ?: '');
define('WHATSAPP_ACCESS_TOKEN', getenv('WHATSAPP_ACCESS_TOKEN') ?: '');

// ─── CORS + Headers ────────────────────────────────────────────────────────────

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-API-Key, X-Auth-Token');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$action = $_GET['action'] ?? '';
$id     = $_GET['id']     ?? '';
$body   = json_decode(file_get_contents('php://input'), true) ?? [];

// ─── Autentificare API Key ─────────────────────────────────────────────────────

$providedKey = $_SERVER['HTTP_X_API_KEY'] ?? ($_GET['api_key'] ?? '');
if ($providedKey !== API_KEY) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// ─── Conectare la baza de date ─────────────────────────────────────────────────

function connectDatabase(string $host, string $name, string $user, string $pass): PDO {
    return new PDO(
        'mysql:host=' . $host . ';dbname=' . $name . ';charset=utf8mb4',
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
}

function connectDatabaseServer(string $host, string $user, string $pass): PDO {
    return new PDO(
        'mysql:host=' . $host . ';charset=utf8mb4',
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
}

// ─── Utilitare ─────────────────────────────────────────────────────────────────

function uuid(): string {
    return sprintf(
        '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

function normalizeWhatsAppPhone(string $phone): string {
    $digits = preg_replace('/\D+/', '', $phone) ?? '';
    if (str_starts_with($digits, '00')) {
        $digits = substr($digits, 2);
    }
    if (str_starts_with($digits, '0') && strlen($digits) === 10) {
        $digits = '40' . substr($digits, 1);
    }
    return $digits;
}

function whatsappApiRequest(string $path, array $payload, bool $multipart = false): array {
    if (WHATSAPP_PHONE_NUMBER_ID === '' || WHATSAPP_ACCESS_TOKEN === '') {
        throw new RuntimeException('Configureaza WHATSAPP_PHONE_NUMBER_ID si WHATSAPP_ACCESS_TOKEN pe server.');
    }
    if (!function_exists('curl_init')) {
        throw new RuntimeException('Extensia PHP cURL nu este activa pe server.');
    }

    $url = 'https://graph.facebook.com/' . WHATSAPP_GRAPH_VERSION . '/' . ltrim($path, '/');
    $curl = curl_init($url);
    $headers = ['Authorization: Bearer ' . WHATSAPP_ACCESS_TOKEN];
    if (!$multipart) {
        $headers[] = 'Content-Type: application/json';
    }
    curl_setopt_array($curl, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_POSTFIELDS => $multipart ? $payload : json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_TIMEOUT => 30,
    ]);
    $raw = curl_exec($curl);
    $status = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $error = curl_error($curl);
    curl_close($curl);

    if ($raw === false || $error !== '') {
        throw new RuntimeException('Eroare conexiune WhatsApp: ' . $error);
    }
    $response = json_decode($raw, true);
    if ($status < 200 || $status >= 300) {
        $message = $response['error']['message'] ?? ('WhatsApp API HTTP ' . $status);
        throw new RuntimeException($message);
    }
    return is_array($response) ? $response : [];
}

function tableExists(PDO $db, string $table): bool {
    static $cache = [];
    if (array_key_exists($table, $cache)) {
        return $cache[$table];
    }
    $stmt = $db->prepare(
        'SELECT COUNT(*)
         FROM INFORMATION_SCHEMA.TABLES
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?'
    );
    $stmt->execute([$table]);
    $cache[$table] = ((int)$stmt->fetchColumn()) > 0;
    return $cache[$table];
}

function columnExists(PDO $db, string $table, string $column): bool {
    static $cache = [];
    $key = $table . '.' . $column;
    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }
    $stmt = $db->prepare(
        'SELECT COUNT(*)
         FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
           AND COLUMN_NAME = ?'
    );
    $stmt->execute([$table, $column]);
    $cache[$key] = ((int)$stmt->fetchColumn()) > 0;
    return $cache[$key];
}

function columnType(PDO $db, string $table, string $column): string {
    $stmt = $db->prepare(
        'SELECT COLUMN_TYPE
         FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
           AND COLUMN_NAME = ?
         LIMIT 1'
    );
    $stmt->execute([$table, $column]);
    return (string)($stmt->fetchColumn() ?: '');
}

function indexExists(PDO $db, string $table, string $index): bool {
    $stmt = $db->prepare(
        'SELECT COUNT(*)
         FROM INFORMATION_SCHEMA.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
           AND INDEX_NAME = ?'
    );
    $stmt->execute([$table, $index]);
    return ((int)$stmt->fetchColumn()) > 0;
}

function splitSqlStatements(string $sql): array {
    $statements = [];
    $buffer = '';
    $quote = null;
    $escaped = false;
    $length = strlen($sql);

    for ($i = 0; $i < $length; $i++) {
        $char = $sql[$i];

        if ($quote !== null) {
            $buffer .= $char;
            if ($escaped) {
                $escaped = false;
                continue;
            }
            if ($char === '\\') {
                $escaped = true;
                continue;
            }
            if ($char === $quote) {
                $quote = null;
            }
            continue;
        }

        if ($char === "'" || $char === '"' || $char === '`') {
            $quote = $char;
            $buffer .= $char;
            continue;
        }

        if ($char === ';') {
            $statement = trim($buffer);
            if ($statement !== '') {
                $statements[] = $statement;
            }
            $buffer = '';
            continue;
        }

        $buffer .= $char;
    }

    $statement = trim($buffer);
    if ($statement !== '') {
        $statements[] = $statement;
    }
    return $statements;
}

function runSchemaSql(PDO $targetDb): int {
    $schemaPath = __DIR__ . '/schema.sql';
    if (!is_file($schemaPath)) {
        throw new RuntimeException('schema.sql nu exista langa api.php pe server.');
    }
    $sql = file_get_contents($schemaPath);
    if ($sql === false || trim($sql) === '') {
        throw new RuntimeException('schema.sql este gol sau nu poate fi citit.');
    }

    $count = 0;
    foreach (splitSqlStatements($sql) as $statement) {
        $targetDb->exec($statement);
        $count++;
    }

    ensureAuthTables($targetDb);
    ensureClientOwnershipSchema($targetDb);
    ensureClientAccessSchema($targetDb);
    ensureClientActivitySchema($targetDb);
    ensurePartnerContactSchema($targetDb);
    ensureCustomExpensesSchema($targetDb);
    ensureChatTables($targetDb);
    ensurePushNotificationTables($targetDb);
    ensureWhatsAppPredefinedMessagesTable($targetDb);
    return $count;
}

function writeServerRuntimeConfig(array $config): void {
    $payload = "<?php\nreturn " . var_export($config, true) . ";\n";
    $tmpPath = SERVER_CONFIG_FILE . '.tmp';
    if (file_put_contents($tmpPath, $payload, LOCK_EX) === false) {
        throw new RuntimeException('Nu pot scrie configuratia serverului.');
    }
    if (!rename($tmpPath, SERVER_CONFIG_FILE)) {
        @unlink($tmpPath);
        throw new RuntimeException('Nu pot salva configuratia serverului.');
    }
}

function prepareSystemDatabase(
    string $dbHost,
    string $dbName,
    string $dbUser,
    string $dbPass,
    bool $runSchema
): array {
    if ($dbHost === '' || $dbName === '' || $dbUser === '') {
        throw new InvalidArgumentException('DB host, DB name si DB user sunt obligatorii.');
    }
    if (strlen($dbName) > 64 || preg_match('/^[A-Za-z0-9_-]+$/', $dbName) !== 1) {
        throw new InvalidArgumentException(
            'DB Name poate contine doar litere, cifre, underscore si minus (maximum 64 caractere).'
        );
    }

    try {
        $serverDb = connectDatabaseServer($dbHost, $dbUser, $dbPass);
    } catch (PDOException $error) {
        throw new RuntimeException(
            'Conexiunea la serverul MySQL a esuat. Verifica DB Host, DB User si DB Password. ' .
            $error->getMessage()
        );
    }

    $existsStmt = $serverDb->prepare(
        'SELECT COUNT(*) FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = ?'
    );
    $existsStmt->execute([$dbName]);
    $databaseExisted = ((int)$existsStmt->fetchColumn()) > 0;

    if (!$databaseExisted) {
        try {
            $quotedDbName = '`' . str_replace('`', '``', $dbName) . '`';
            $serverDb->exec(
                'CREATE DATABASE ' . $quotedDbName .
                ' CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci'
            );
        } catch (PDOException $error) {
            throw new RuntimeException(
                'Baza de date nu exista, iar utilizatorul MySQL nu o poate crea. ' .
                'Acorda permisiunea CREATE DATABASE sau creeaz-o manual. ' . $error->getMessage()
            );
        }
    }

    try {
        $targetDb = connectDatabase($dbHost, $dbName, $dbUser, $dbPass);
    } catch (PDOException $error) {
        throw new RuntimeException(
            'Baza a fost gasita sau creata, dar conexiunea la ea a esuat. ' . $error->getMessage()
        );
    }

    $schemaStatements = 0;
    if ($runSchema) {
        $schemaStatements = runSchemaSql($targetDb);
    } else {
        ensureAuthTables($targetDb);
    }

    $adminStmt = $targetDb->prepare(
        'SELECT password_hash FROM app_users WHERE username = ? AND is_active = 1 LIMIT 1'
    );
    $adminStmt->execute([DEFAULT_ADMIN_USER]);
    $adminHash = (string)($adminStmt->fetchColumn() ?: '');

    return [
        'database_created' => !$databaseExisted,
        'schema_ran' => $runSchema,
        'schema_statements' => $schemaStatements,
        'default_admin_ready' => $adminHash !== '' && password_verify(DEFAULT_ADMIN_PASS, $adminHash),
    ];
}

function bootstrapSystem(array $body): array {
    $apiKey = trim((string)($body['api_key'] ?? API_KEY));
    $dbHost = trim((string)($body['db_host'] ?? ''));
    $dbName = trim((string)($body['db_name'] ?? ''));
    $dbUser = trim((string)($body['db_user'] ?? ''));
    $dbPass = (string)($body['db_pass'] ?? '');
    $runSchema = !array_key_exists('run_schema', $body) || !empty($body['run_schema']);

    if ($apiKey === '') {
        throw new InvalidArgumentException('API Key este obligatoriu.');
    }
    if ($runSchema && !is_file(__DIR__ . '/schema.sql')) {
        throw new RuntimeException(
            'schema.sql nu exista langa api.php pe noul server. Urca ambele fisiere in acelasi folder.'
        );
    }

    $databaseResult = prepareSystemDatabase(
        $dbHost,
        $dbName,
        $dbUser,
        $dbPass,
        $runSchema
    );

    writeServerRuntimeConfig([
        'api_key' => $apiKey,
        'db_host' => $dbHost,
        'db_name' => $dbName,
        'db_user' => $dbUser,
        'db_pass' => $dbPass,
    ]);

    return array_merge($databaseResult, [
        'success' => true,
        'config_file_saved' => true,
        'target_database' => $dbName,
        'admin_username' => DEFAULT_ADMIN_USER,
        'default_admin_ready' => $databaseResult['default_admin_ready'],
        'message' => $databaseResult['default_admin_ready']
            ? 'Serverul a fost initializat. Te poti autentifica folosind admin / admin.'
            : 'Serverul a fost initializat, iar contul admin existent si-a pastrat parola.',
    ]);
}

function publicApiBaseUrl(): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
        (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return $scheme . '://' . $host . ($dir === '' ? '' : $dir);
}

function buildCollaborator(array $row): array {
    return [
        'id'         => $row['id'],
        'name'       => $row['name'],
        'role'       => $row['role'] ?? '',
        'phone'      => $row['phone'] ?? '',
        'email'      => $row['email'] ?? '',
        'color'      => $row['color'] ?? '#14B8A6',
        'created_at' => $row['created_at'] ?? '',
    ];
}

function collaboratorCostsPayloadTotal(array $costs): float {
    $total = 0.0;
    foreach ($costs as $cost) {
        $total += max((float)($cost['cost'] ?? 0), 0);
    }
    return $total;
}

function getClientCollaboratorCosts(PDO $db, string $clientId): array {
    if (!tableExists($db, 'client_collaborator_costs')) {
        return [];
    }

    $stmt = $db->prepare(
        'SELECT cc.id, cc.collaborator_id,
                COALESCE(co.name, cc.collaborator_name) AS collaborator_name,
                COALESCE(co.role, "") AS collaborator_role,
                COALESCE(co.color, cc.collaborator_color) AS collaborator_color,
                cc.cost, cc.created_at
         FROM client_collaborator_costs cc
         LEFT JOIN collaborators co ON cc.collaborator_id = co.id
         WHERE cc.client_id = ?
         ORDER BY collaborator_name ASC'
    );
    $stmt->execute([$clientId]);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['cost'] = (float)$row['cost'];
    }
    return $rows;
}

function saveClientCollaboratorCosts(PDO $db, string $clientId, array $costs): float {
    if (!tableExists($db, 'client_collaborator_costs') || !tableExists($db, 'collaborators')) {
        return collaboratorCostsPayloadTotal($costs);
    }

    $deleteStmt = $db->prepare('DELETE FROM client_collaborator_costs WHERE client_id = ?');
    $deleteStmt->execute([$clientId]);

    $selectStmt = $db->prepare('SELECT * FROM collaborators WHERE id = ?');
    $insertStmt = $db->prepare(
        'INSERT INTO client_collaborator_costs
         (id, client_id, collaborator_id, collaborator_name, collaborator_color, cost)
         VALUES (?, ?, ?, ?, ?, ?)'
    );

    $total = 0.0;
    foreach ($costs as $item) {
        $collaboratorId = trim($item['collaborator_id'] ?? '');
        $cost = max((float)($item['cost'] ?? 0), 0);
        if ($collaboratorId === '') {
            continue;
        }

        $selectStmt->execute([$collaboratorId]);
        $collaborator = $selectStmt->fetch();
        if (!$collaborator) {
            continue;
        }

        $insertStmt->execute([
            uuid(),
            $clientId,
            $collaboratorId,
            $collaborator['name'],
            $collaborator['color'] ?? '#14B8A6',
            $cost,
        ]);
        $total += $cost;
    }

    return $total;
}

function buildExpenseCategory(array $row): array {
    return [
        'id'         => $row['id'],
        'name'       => $row['name'],
        'color'      => $row['color'] ?? '#EF4444',
        'created_at' => $row['created_at'] ?? '',
    ];
}

function expenseCostsPayloadTotal(array $costs): float {
    $total = 0.0;
    foreach ($costs as $cost) {
        $total += max((float)($cost['cost'] ?? 0), 0);
    }
    return $total;
}

function getClientExpenseCosts(PDO $db, string $clientId): array {
    if (!tableExists($db, 'client_expense_costs')) {
        return [];
    }

    $stmt = $db->prepare(
        'SELECT ce.id, ce.expense_id,
                COALESCE(ec.name, ce.expense_name) AS expense_name,
                COALESCE(ec.color, ce.expense_color) AS expense_color,
                ce.cost, ce.created_at
         FROM client_expense_costs ce
         LEFT JOIN expense_categories ec ON ce.expense_id = ec.id
         WHERE ce.client_id = ?
         ORDER BY expense_name ASC'
    );
    $stmt->execute([$clientId]);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['cost'] = (float)$row['cost'];
    }
    return $rows;
}

function saveClientExpenseCosts(PDO $db, string $clientId, array $costs): float {
    if (!tableExists($db, 'client_expense_costs') || !tableExists($db, 'expense_categories')) {
        return expenseCostsPayloadTotal($costs);
    }

    // Past values whose category was deleted remain immutable snapshots.
    $db->prepare('DELETE FROM client_expense_costs WHERE client_id = ? AND expense_id IS NOT NULL')
        ->execute([$clientId]);
    $selectStmt = $db->prepare('SELECT * FROM expense_categories WHERE id = ?');
    $insertStmt = $db->prepare(
        'INSERT INTO client_expense_costs
         (id, client_id, expense_id, expense_name, expense_color, cost)
         VALUES (?, ?, ?, ?, ?, ?)'
    );

    $total = 0.0;
    foreach ($costs as $item) {
        $expenseId = trim($item['expense_id'] ?? '');
        $cost = max((float)($item['cost'] ?? 0), 0);
        if ($expenseId === '') {
            continue;
        }
        $selectStmt->execute([$expenseId]);
        $expense = $selectStmt->fetch();
        if (!$expense) {
            continue;
        }
        $insertStmt->execute([
            uuid(),
            $clientId,
            $expenseId,
            $expense['name'],
            $expense['color'] ?? '#EF4444',
            $cost,
        ]);
        $total += $cost;
    }
    $sumStmt = $db->prepare('SELECT COALESCE(SUM(cost), 0) FROM client_expense_costs WHERE client_id = ?');
    $sumStmt->execute([$clientId]);
    return (float)$sumStmt->fetchColumn();
}

function ensureCustomExpensesSchema(PDO $db): void {
    $db->exec(
        "CREATE TABLE IF NOT EXISTS `expense_categories` (
          `id` CHAR(36) NOT NULL PRIMARY KEY,
          `name` VARCHAR(255) NOT NULL,
          `color` VARCHAR(7) NOT NULL DEFAULT '#EF4444',
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    if (tableExists($db, 'clients') && !columnExists($db, 'clients', 'alte_cheltuieli')) {
        $db->exec(
            'ALTER TABLE clients
             ADD COLUMN alte_cheltuieli DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER valoare_piese'
        );
    }

    $db->exec(
        "CREATE TABLE IF NOT EXISTS `client_expense_costs` (
          `id` CHAR(36) NOT NULL PRIMARY KEY,
          `client_id` CHAR(36) NOT NULL,
          `expense_id` CHAR(36) DEFAULT NULL,
          `expense_name` VARCHAR(255) NOT NULL,
          `expense_color` VARCHAR(7) NOT NULL DEFAULT '#EF4444',
          `cost` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          KEY `idx_client_expense_client` (`client_id`),
          KEY `idx_client_expense_category` (`expense_id`),
          CONSTRAINT `fk_client_expense_client`
            FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`)
            ON DELETE CASCADE ON UPDATE CASCADE,
          CONSTRAINT `fk_client_expense_category`
            FOREIGN KEY (`expense_id`) REFERENCES `expense_categories`(`id`)
            ON DELETE SET NULL ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
}

function ensureAuthTables(PDO $db): void {
    $db->exec(
        "CREATE TABLE IF NOT EXISTS `app_users` (
          `id` CHAR(36) NOT NULL PRIMARY KEY,
          `username` VARCHAR(80) NOT NULL,
          `password_hash` VARCHAR(255) NOT NULL,
          `display_name` VARCHAR(255) NOT NULL,
          `role` ENUM('admin','manager','user') NOT NULL DEFAULT 'user',
          `platform_access` ENUM('desktop','mobile','both') NOT NULL DEFAULT 'mobile',
          `support_chat_access` TINYINT(1) NOT NULL DEFAULT 0,
          `client_edit_access` TINYINT(1) NOT NULL DEFAULT 0,
          `is_active` TINYINT(1) NOT NULL DEFAULT 1,
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY `uq_app_users_username` (`username`),
          KEY `idx_app_users_role` (`role`),
          KEY `idx_app_users_platform` (`platform_access`),
          KEY `idx_app_users_support_chat` (`support_chat_access`),
          KEY `idx_app_users_client_edit` (`client_edit_access`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    if (!columnExists($db, 'app_users', 'support_chat_access')) {
        $db->exec(
            'ALTER TABLE app_users
             ADD COLUMN support_chat_access TINYINT(1) NOT NULL DEFAULT 0 AFTER platform_access,
             ADD KEY idx_app_users_support_chat (support_chat_access)'
        );
    }
    if (!columnExists($db, 'app_users', 'client_edit_access')) {
        $db->exec(
            'ALTER TABLE app_users
             ADD COLUMN client_edit_access TINYINT(1) NOT NULL DEFAULT 0 AFTER support_chat_access,
             ADD KEY idx_app_users_client_edit (client_edit_access)'
        );
    }

    $platformColumn = $db->query("SHOW COLUMNS FROM app_users LIKE 'platform_access'")->fetch();
    if ($platformColumn && strpos((string)($platformColumn['Type'] ?? ''), "'both'") === false) {
        $db->exec(
            "ALTER TABLE app_users
             MODIFY COLUMN platform_access ENUM('desktop','mobile','both') NOT NULL DEFAULT 'mobile'"
        );
    }

    $db->exec(
        "CREATE TABLE IF NOT EXISTS `app_sessions` (
          `id` CHAR(36) NOT NULL PRIMARY KEY,
          `user_id` CHAR(36) NOT NULL,
          `token_hash` CHAR(64) NOT NULL,
          `platform` ENUM('desktop','mobile') NOT NULL,
          `expires_at` TIMESTAMP NOT NULL,
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY `uq_app_sessions_token` (`token_hash`),
          KEY `idx_app_sessions_user` (`user_id`),
          KEY `idx_app_sessions_expires` (`expires_at`),
          FOREIGN KEY (`user_id`) REFERENCES `app_users`(`id`)
            ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $stmt = $db->prepare('SELECT id FROM app_users WHERE username = ? LIMIT 1');
    $stmt->execute([DEFAULT_ADMIN_USER]);
    if (!$stmt->fetch()) {
        $insert = $db->prepare(
            'INSERT INTO app_users (id, username, password_hash, display_name, role, platform_access, support_chat_access, client_edit_access, is_active)
             VALUES (?, ?, ?, ?, "admin", "both", 1, 1, 1)'
        );
        $insert->execute([
            uuid(),
            DEFAULT_ADMIN_USER,
            password_hash(DEFAULT_ADMIN_PASS, PASSWORD_DEFAULT),
            DEFAULT_ADMIN_NAME,
        ]);
    }

    $rootAdminStmt = $db->prepare(
        'UPDATE app_users
         SET role = "admin", platform_access = "both", support_chat_access = 1, client_edit_access = 1, is_active = 1
         WHERE username = ?'
    );
    $rootAdminStmt->execute([DEFAULT_ADMIN_USER]);
}

function ensureWhatsAppPredefinedMessagesTable(PDO $db): void {
    $db->exec(
        "CREATE TABLE IF NOT EXISTS `whatsapp_predefined_messages` (
          `id` CHAR(36) NOT NULL PRIMARY KEY,
          `title` VARCHAR(120) NOT NULL,
          `body` TEXT NOT NULL,
          `created_by` CHAR(36) DEFAULT NULL,
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          KEY `idx_whatsapp_messages_updated` (`updated_at`),
          FOREIGN KEY (`created_by`) REFERENCES `app_users`(`id`)
            ON DELETE SET NULL ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
}

function ensureClientOwnershipSchema(PDO $db): void {
    if (!tableExists($db, 'clients')) {
        return;
    }

    if (!columnExists($db, 'clients', 'owner_user_id')) {
        $db->exec(
            'ALTER TABLE clients
             ADD COLUMN owner_user_id CHAR(36) DEFAULT NULL AFTER profile_id,
             ADD KEY idx_clients_owner_user (owner_user_id),
             ADD CONSTRAINT fk_clients_owner_user
               FOREIGN KEY (owner_user_id) REFERENCES app_users(id)
               ON DELETE SET NULL ON UPDATE CASCADE'
        );
    }
}

function ensurePartnerContactSchema(PDO $db): void {
    foreach (['profiles', 'collaborators'] as $table) {
        if (!tableExists($db, $table)) {
            continue;
        }
        if (!columnExists($db, $table, 'phone')) {
            $db->exec("ALTER TABLE {$table} ADD COLUMN phone VARCHAR(50) DEFAULT NULL AFTER role");
        }
        if (!columnExists($db, $table, 'email')) {
            $db->exec("ALTER TABLE {$table} ADD COLUMN email VARCHAR(255) DEFAULT NULL AFTER phone");
        }
    }
}

function ensureClientAccessSchema(PDO $db): void {
    if (!tableExists($db, 'clients')) {
        return;
    }

    $db->exec(
        "CREATE TABLE IF NOT EXISTS `client_user_access` (
          `id` CHAR(36) NOT NULL PRIMARY KEY,
          `client_id` CHAR(36) NOT NULL,
          `user_id` CHAR(36) NOT NULL,
          `source` ENUM('owner','scan','manual') NOT NULL DEFAULT 'manual',
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY `uq_client_user_access` (`client_id`, `user_id`),
          KEY `idx_client_user_access_user` (`user_id`),
          KEY `idx_client_user_access_client` (`client_id`),
          FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`)
            ON DELETE CASCADE ON UPDATE CASCADE,
          FOREIGN KEY (`user_id`) REFERENCES `app_users`(`id`)
            ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $db->exec(
        "INSERT INTO client_user_access (id, client_id, user_id, source)
         SELECT UUID(), c.id, c.owner_user_id, 'owner'
         FROM clients c
         LEFT JOIN client_user_access cua
           ON cua.client_id = c.id AND cua.user_id = c.owner_user_id
         WHERE c.owner_user_id IS NOT NULL
           AND cua.id IS NULL"
    );
}

function ensureClientActivitySchema(PDO $db): void {
    if (!tableExists($db, 'clients')) {
        return;
    }

    $activityTableExisted = tableExists($db, 'client_activity_logs');
    $db->exec(
        "CREATE TABLE IF NOT EXISTS `client_activity_logs` (
          `id` CHAR(36) NOT NULL PRIMARY KEY,
          `client_id` CHAR(36) NOT NULL,
          `actor_user_id` CHAR(36) DEFAULT NULL,
          `action` ENUM('created','updated','scanned','finalized','deleted') NOT NULL,
          `summary` VARCHAR(255) NOT NULL DEFAULT '',
          `details` TEXT DEFAULT NULL,
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          KEY `idx_client_activity_client` (`client_id`, `created_at`),
          KEY `idx_client_activity_actor` (`actor_user_id`),
          FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`)
            ON DELETE CASCADE ON UPDATE CASCADE,
          FOREIGN KEY (`actor_user_id`) REFERENCES `app_users`(`id`)
            ON DELETE SET NULL ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    if (!$activityTableExisted) {
        $db->exec(
            "INSERT INTO client_activity_logs (id, client_id, actor_user_id, action, summary, details, created_at)
             SELECT UUID(), c.id, c.owner_user_id, 'created', 'Client adaugat',
                    JSON_OBJECT('name', c.name, 'phone', c.phone, 'qr_code', c.qr_code),
                    c.created_at
             FROM clients c"
        );
    }
}

function buildAppUser(array $row): array {
    return [
        'id'              => $row['id'],
        'username'        => $row['username'],
        'display_name'    => $row['display_name'],
        'role'            => $row['role'],
        'platform_access' => $row['platform_access'],
        'support_chat_access' => (bool)($row['support_chat_access'] ?? false),
        'client_edit_access' => (bool)($row['client_edit_access'] ?? false),
        'is_active'       => (bool)$row['is_active'],
        'created_at'      => $row['created_at'] ?? '',
        'updated_at'      => $row['updated_at'] ?? '',
    ];
}

function userCanAccessPlatform(array $user, string $platform): bool {
    return $user['platform_access'] === 'both' || $user['platform_access'] === $platform;
}

function isSupportChatAgent(array $user): bool {
    return !empty($user['support_chat_access']);
}

function userCanEditClients(array $user): bool {
    return in_array($user['role'] ?? '', ['admin', 'manager'], true)
        || !empty($user['client_edit_access']);
}

function userCanFinalizeClients(array $user): bool {
    return in_array($user['role'] ?? '', ['admin', 'manager'], true);
}

function isChatSupervisor(array $user): bool {
    return ($user['role'] ?? '') === 'admin';
}

function requireSupportChatAgent(PDO $db, array $body): array {
    $user = requireAuth($db, $body);
    if (!isSupportChatAgent($user)) {
        http_response_code(403);
        echo json_encode(['error' => 'Acces Support Chat necesar.']);
        exit();
    }
    return $user;
}

function requireChatRequester(PDO $db, array $body): array {
    $user = requireAuth($db, $body);
    if (isSupportChatAgent($user)) {
        http_response_code(403);
        echo json_encode(['error' => 'Conturile Agent Support folosesc consola de agent.']);
        exit();
    }
    return $user;
}

function getChatRequesterById(PDO $db, string $userId): ?array {
    $stmt = $db->prepare(
        'SELECT * FROM app_users
         WHERE id = ? AND is_active = 1 AND support_chat_access = 0
         LIMIT 1'
    );
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    return $user ?: null;
}

function ensurePushNotificationTables(PDO $db): void {
    $db->exec(
        "CREATE TABLE IF NOT EXISTS `app_push_tokens` (
          `id` CHAR(36) NOT NULL PRIMARY KEY,
          `user_id` CHAR(36) NOT NULL,
          `token` VARCHAR(255) NOT NULL,
          `platform` VARCHAR(32) NOT NULL DEFAULT 'android',
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          `last_seen_at` TIMESTAMP NULL DEFAULT NULL,
          UNIQUE KEY `uq_app_push_token` (`token`),
          KEY `idx_app_push_user` (`user_id`),
          CONSTRAINT `fk_app_push_user`
            FOREIGN KEY (`user_id`) REFERENCES `app_users`(`id`)
            ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
}

function isExpoPushToken(string $token): bool {
    return preg_match('/^(ExponentPushToken|ExpoPushToken)\[[A-Za-z0-9_\-]+\]$/', $token) === 1;
}

function pushTextPreview(string $text): string {
    $text = trim(preg_replace('/\s+/', ' ', $text) ?? '');
    if (function_exists('mb_strlen') && function_exists('mb_substr')) {
        return mb_strlen($text, 'UTF-8') > 160 ? mb_substr($text, 0, 157, 'UTF-8') . '...' : $text;
    }
    return strlen($text) > 160 ? substr($text, 0, 157) . '...' : $text;
}

function pushRecipientIdsForChat(PDO $db, string $recipientRole, string $recipientId, array $conversation): array {
    if ($recipientRole === 'mobile') {
        return [$recipientId];
    }

    if (!empty($conversation['assigned_agent_id'])) {
        $stmt = $db->prepare(
            'SELECT id FROM app_users
             WHERE is_active = 1
               AND support_chat_access = 1
               AND (role = "admin" OR id = ?)'
        );
        $stmt->execute([$conversation['assigned_agent_id']]);
    } else {
        $stmt = $db->query(
            'SELECT id FROM app_users
             WHERE is_active = 1
               AND support_chat_access = 1'
        );
    }

    return array_values(array_unique(array_filter(array_map('strval', $stmt->fetchAll(PDO::FETCH_COLUMN)))));
}

function sendExpoPushRequest(array $messages): array {
    if (empty($messages)) {
        return [];
    }

    $payload = json_encode($messages, JSON_UNESCAPED_UNICODE);
    if ($payload === false) {
        return [];
    }

    $url = 'https://exp.host/--/api/v2/push/send';
    if (function_exists('curl_init')) {
        $curl = curl_init($url);
        curl_setopt_array($curl, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Content-Type: application/json',
            ],
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_TIMEOUT => 8,
        ]);
        $raw = curl_exec($curl);
        $status = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curlError = curl_error($curl);
        curl_close($curl);
        if ($raw === false || $status < 200 || $status >= 300) {
            error_log('[G-Trots Push] Expo request failed. HTTP ' . $status . ' - ' . ($raw === false ? $curlError : $raw));
            return [];
        }
    } else {
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => "Accept: application/json\r\nContent-Type: application/json\r\n",
                'content' => $payload,
                'timeout' => 8,
            ],
        ]);
        $raw = @file_get_contents($url, false, $context);
        if ($raw === false) {
            error_log('[G-Trots Push] Expo request failed through file_get_contents.');
            return [];
        }
    }

    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function pruneDeadExpoTokens(PDO $db, array $tokens, array $response): void {
    $rows = $response['data'] ?? [];
    if (!is_array($rows)) {
        return;
    }

    foreach ($rows as $index => $row) {
        if (!is_array($row)) {
            continue;
        }
        $error = $row['details']['error'] ?? '';
        if (($row['status'] ?? '') === 'error') {
            error_log('[G-Trots Push] Delivery rejected: ' . json_encode($row, JSON_UNESCAPED_UNICODE));
        }
        if (($row['status'] ?? '') === 'error' && $error === 'DeviceNotRegistered' && isset($tokens[$index])) {
            $stmt = $db->prepare('DELETE FROM app_push_tokens WHERE token = ?');
            $stmt->execute([$tokens[$index]]);
        }
    }
}

function sendPushNotificationToUsers(PDO $db, array $userIds, string $title, string $body, array $data = []): void {
    $userIds = array_values(array_unique(array_filter($userIds)));
    if (empty($userIds)) {
        return;
    }

    $placeholders = implode(',', array_fill(0, count($userIds), '?'));
    $stmt = $db->prepare(
        "SELECT token FROM app_push_tokens
         WHERE user_id IN ($placeholders)"
    );
    $stmt->execute($userIds);
    $tokens = array_values(array_unique(array_filter($stmt->fetchAll(PDO::FETCH_COLUMN), 'isExpoPushToken')));
    if (empty($tokens)) {
        error_log('[G-Trots Push] No registered Expo tokens for users: ' . implode(',', $userIds));
        return;
    }

    $messages = array_map(static function (string $token) use ($title, $body, $data): array {
        return [
            'to' => $token,
            'sound' => 'default',
            'title' => $title,
            'body' => pushTextPreview($body),
            'priority' => 'high',
            'channelId' => 'chat',
            'data' => $data,
        ];
    }, $tokens);

    foreach (array_chunk($messages, 100) as $chunk) {
        $chunkTokens = array_column($chunk, 'to');
        $response = sendExpoPushRequest($chunk);
        if (empty($response)) {
            error_log('[G-Trots Push] Empty Expo response for ' . count($chunk) . ' notification(s).');
        }
        pruneDeadExpoTokens($db, $chunkTokens, $response);
    }
}

function createSession(PDO $db, string $userId, string $platform): string {
    $token = bin2hex(random_bytes(32));
    $stmt = $db->prepare(
        'INSERT INTO app_sessions (id, user_id, token_hash, platform, expires_at)
         VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))'
    );
    $stmt->execute([uuid(), $userId, hash('sha256', $token), $platform]);
    return $token;
}

function currentAuthToken(array $body): string {
    return $_SERVER['HTTP_X_AUTH_TOKEN']
        ?? ($_GET['authToken'] ?? ($_GET['adminToken'] ?? ($body['auth_token'] ?? ($body['admin_token'] ?? ''))));
}

function requireAuth(PDO $db, array $body, ?string $platform = null, array $roles = []): array {
    ensureAuthTables($db);
    $token = currentAuthToken($body);
    if ($token === '') {
        http_response_code(401);
        echo json_encode(['error' => 'Autentificare necesara.']);
        exit();
    }

    $stmt = $db->prepare(
        'SELECT u.*, s.platform, s.expires_at
         FROM app_sessions s
         JOIN app_users u ON u.id = s.user_id
         WHERE s.token_hash = ? AND s.expires_at > NOW() AND u.is_active = 1
         LIMIT 1'
    );
    $stmt->execute([hash('sha256', $token)]);
    $user = $stmt->fetch();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Sesiune expirata sau invalida.']);
        exit();
    }
    $sessionPlatform = $user['platform'] ?? '';
    if (!userCanAccessPlatform($user, $sessionPlatform)) {
        http_response_code(403);
        echo json_encode(['error' => 'Contul nu mai are acces la aceasta platforma.']);
        exit();
    }
    if ($platform && $sessionPlatform !== $platform) {
        http_response_code(403);
        echo json_encode(['error' => 'Sesiunea nu este valida pentru aceasta platforma.']);
        exit();
    }
    if (!empty($roles) && !in_array($user['role'], $roles, true)) {
        http_response_code(403);
        echo json_encode(['error' => 'Nu ai permisiune pentru aceasta actiune.']);
        exit();
    }
    return $user;
}

function requireAdmin(PDO $db, array $body): array {
    return requireAuth($db, $body, null, ['admin']);
}

function currentUserOrNull(PDO $db, array $body, ?string $platform = null): ?array {
    if (currentAuthToken($body) === '') {
        return null;
    }
    return requireAuth($db, $body, $platform);
}

function isRestrictedMobileUser(?array $user): bool {
    return !empty($user)
        && ($user['role'] ?? '') === 'user'
        && ($user['platform'] ?? '') === 'mobile';
}

function userHasClientAccess(PDO $db, ?array $user, array $client): bool {
    if (empty($user)) {
        return false;
    }
    if (in_array($user['role'] ?? '', ['admin', 'manager'], true)) {
        return true;
    }
    if (($client['owner_user_id'] ?? null) === ($user['id'] ?? null)) {
        return true;
    }
    if (!tableExists($db, 'client_user_access')) {
        return false;
    }

    $stmt = $db->prepare('SELECT 1 FROM client_user_access WHERE client_id = ? AND user_id = ? LIMIT 1');
    $stmt->execute([$client['id'] ?? '', $user['id'] ?? '']);
    return (bool)$stmt->fetchColumn();
}

function grantClientAccess(PDO $db, string $clientId, ?string $userId, string $source = 'manual'): void {
    if (!$userId || !tableExists($db, 'client_user_access')) {
        return;
    }

    if (!in_array($source, ['owner', 'scan', 'manual'], true)) {
        $source = 'manual';
    }

    $stmt = $db->prepare(
        'INSERT INTO client_user_access (id, client_id, user_id, source)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE source = source'
    );
    $stmt->execute([uuid(), $clientId, $userId, $source]);
}

function logClientActivity(
    PDO $db,
    string $clientId,
    ?array $actor,
    string $action,
    string $summary,
    array $details = []
): void {
    if (!in_array($action, ['created', 'updated', 'scanned', 'finalized', 'deleted'], true)) {
        return;
    }

    $stmt = $db->prepare(
        'INSERT INTO client_activity_logs (id, client_id, actor_user_id, action, summary, details)
         VALUES (?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        uuid(),
        $clientId,
        $actor['id'] ?? null,
        $action,
        $summary,
        !empty($details) ? json_encode($details, JSON_UNESCAPED_UNICODE) : null,
    ]);
}

function clientFieldChanges(array $before, array $after): array {
    $fields = [
        'name' => 'Nume',
        'phone' => 'Telefon',
        'email' => 'Email',
        'status' => 'Status',
        'price' => 'Pret lucrare',
        'discount_percentage' => 'Reducere',
        'manopera_colaboratori' => 'Manopera colaboratori',
        'valoare_piese' => 'Valoare piese',
        'alte_cheltuieli' => 'Alte cheltuieli',
        'notes' => 'Note',
        'profile_id' => 'Profil afiliere',
        'is_finalized' => 'Finalizat',
        'qr_used' => 'QR folosit',
    ];
    $changes = [];
    foreach ($fields as $field => $label) {
        $old = $before[$field] ?? null;
        $new = $after[$field] ?? null;
        if (in_array($field, ['price', 'discount_percentage', 'manopera_colaboratori', 'valoare_piese', 'alte_cheltuieli'], true)) {
            $old = (float)$old;
            $new = (float)$new;
        } else {
            $old = $old === null ? '' : trim((string)$old);
            $new = $new === null ? '' : trim((string)$new);
        }
        if ((string)$old !== (string)$new) {
            $changes[] = [
                'field' => $field,
                'label' => $label,
                'from' => $old,
                'to' => $new,
            ];
        }
    }
    return $changes;
}

function ensureChatTables(PDO $db): void {
    $db->exec(
        "CREATE TABLE IF NOT EXISTS `chat_conversations` (
          `id` CHAR(36) NOT NULL PRIMARY KEY,
          `mobile_account` VARCHAR(64) NOT NULL,
          `admin_account` VARCHAR(64) NOT NULL DEFAULT 'admin',
          `assigned_agent_id` CHAR(36) DEFAULT NULL,
          `assigned_at` TIMESTAMP NULL DEFAULT NULL,
          `status` ENUM('active','left','closed') NOT NULL DEFAULT 'active',
          `left_at` TIMESTAMP NULL DEFAULT NULL,
          `closed_at` TIMESTAMP NULL DEFAULT NULL,
          `title` VARCHAR(255) NOT NULL DEFAULT 'Mobile 1',
          `last_message_at` TIMESTAMP NULL DEFAULT NULL,
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          KEY `idx_chat_mobile_status` (`mobile_account`, `status`),
          KEY `idx_chat_assigned_agent` (`assigned_agent_id`),
          KEY `idx_chat_last_message` (`last_message_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    if (!columnExists($db, 'chat_conversations', 'assigned_agent_id')) {
        $db->exec(
            'ALTER TABLE chat_conversations
             ADD COLUMN assigned_agent_id CHAR(36) DEFAULT NULL AFTER admin_account,
             ADD COLUMN assigned_at TIMESTAMP NULL DEFAULT NULL AFTER assigned_agent_id,
             ADD KEY idx_chat_assigned_agent (assigned_agent_id)'
        );
    } elseif (!columnExists($db, 'chat_conversations', 'assigned_at')) {
        $db->exec(
            'ALTER TABLE chat_conversations
             ADD COLUMN assigned_at TIMESTAMP NULL DEFAULT NULL AFTER assigned_agent_id'
        );
    }
    if (!columnExists($db, 'chat_conversations', 'status')) {
        $db->exec(
            "ALTER TABLE chat_conversations
             ADD COLUMN status ENUM('active','left','closed') NOT NULL DEFAULT 'active' AFTER assigned_at,
             ADD COLUMN left_at TIMESTAMP NULL DEFAULT NULL AFTER status,
             ADD COLUMN closed_at TIMESTAMP NULL DEFAULT NULL AFTER left_at"
        );
    } elseif (!columnExists($db, 'chat_conversations', 'left_at')) {
        $db->exec(
            'ALTER TABLE chat_conversations
             ADD COLUMN left_at TIMESTAMP NULL DEFAULT NULL AFTER status'
        );
    }
    if (columnExists($db, 'chat_conversations', 'status')
        && strpos(columnType($db, 'chat_conversations', 'status'), "'closed'") === false) {
        $db->exec(
            "ALTER TABLE chat_conversations
             MODIFY COLUMN status ENUM('active','left','closed') NOT NULL DEFAULT 'active'"
        );
    }
    if (!columnExists($db, 'chat_conversations', 'closed_at')) {
        $db->exec(
            'ALTER TABLE chat_conversations
             ADD COLUMN closed_at TIMESTAMP NULL DEFAULT NULL AFTER left_at'
        );
    }
    if (indexExists($db, 'chat_conversations', 'uq_chat_mobile_account')) {
        $db->exec('ALTER TABLE chat_conversations DROP INDEX uq_chat_mobile_account');
    }
    if (!indexExists($db, 'chat_conversations', 'idx_chat_mobile_status')) {
        $db->exec('ALTER TABLE chat_conversations ADD KEY idx_chat_mobile_status (mobile_account, status)');
    }

    $db->exec(
        "CREATE TABLE IF NOT EXISTS `chat_messages` (
          `id` CHAR(36) NOT NULL PRIMARY KEY,
          `conversation_id` CHAR(36) NOT NULL,
          `sender_role` ENUM('mobile','admin') NOT NULL,
          `sender_id` VARCHAR(64) NOT NULL,
          `recipient_role` ENUM('mobile','admin') NOT NULL,
          `recipient_id` VARCHAR(64) NOT NULL,
          `body` TEXT NOT NULL,
          `read_by_mobile` TINYINT(1) NOT NULL DEFAULT 0,
          `read_by_admin` TINYINT(1) NOT NULL DEFAULT 0,
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          KEY `idx_chat_messages_conversation` (`conversation_id`, `created_at`),
          KEY `idx_chat_messages_mobile_unread` (`recipient_id`, `read_by_mobile`, `created_at`),
          KEY `idx_chat_messages_admin_unread` (`recipient_role`, `read_by_admin`, `created_at`),
          CONSTRAINT `fk_chat_messages_conversation`
            FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations`(`id`)
            ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

}

function releaseChatAssignmentsForUser(PDO $db, string $userId): void {
    if ($userId === '' || !tableExists($db, 'chat_conversations')) {
        return;
    }
    $stmt = $db->prepare(
        'UPDATE chat_conversations
         SET assigned_agent_id = NULL, assigned_at = NULL
         WHERE assigned_agent_id = ?'
    );
    $stmt->execute([$userId]);
}

function getChatConversationByMobile(PDO $db, string $mobileAccount): ?array {
    $stmt = $db->prepare(
        'SELECT cc.*,
                au.id AS assigned_agent_user_id,
                au.is_active AS assigned_agent_active,
                au.support_chat_access AS assigned_agent_chat_access,
                au.display_name AS assigned_agent_name,
                au.username AS assigned_agent_username,
                au.role AS assigned_agent_role
         FROM chat_conversations cc
         LEFT JOIN app_users au ON au.id = cc.assigned_agent_id
         WHERE cc.mobile_account = ? AND cc.status = "active"
         ORDER BY cc.created_at DESC
         LIMIT 1'
    );
    $stmt->execute([$mobileAccount]);
    $conversation = $stmt->fetch();
    if ($conversation
        && !empty($conversation['assigned_agent_id'])
        && (empty($conversation['assigned_agent_user_id'])
            || empty($conversation['assigned_agent_active'])
            || empty($conversation['assigned_agent_chat_access']))) {
        $release = $db->prepare(
            'UPDATE chat_conversations
             SET assigned_agent_id = NULL, assigned_at = NULL
             WHERE id = ? AND assigned_agent_id = ?'
        );
        $release->execute([$conversation['id'], $conversation['assigned_agent_id']]);
        $stmt->execute([$mobileAccount]);
        $conversation = $stmt->fetch();
    }
    return $conversation ?: null;
}

function getChatConversationById(PDO $db, string $conversationId): ?array {
    $stmt = $db->prepare(
        'SELECT cc.*,
                au.id AS assigned_agent_user_id,
                au.is_active AS assigned_agent_active,
                au.support_chat_access AS assigned_agent_chat_access,
                au.display_name AS assigned_agent_name,
                au.username AS assigned_agent_username,
                au.role AS assigned_agent_role
         FROM chat_conversations cc
         LEFT JOIN app_users au ON au.id = cc.assigned_agent_id
         WHERE cc.id = ?
         LIMIT 1'
    );
    $stmt->execute([$conversationId]);
    return $stmt->fetch() ?: null;
}

function getOrCreateChatConversation(PDO $db, string $mobileAccount, string $title = ''): array {
    ensureChatTables($db);
    $conversation = getChatConversationByMobile($db, $mobileAccount);
    if ($conversation) {
        return $conversation;
    }

    $newId = uuid();
    $title = trim($title) !== '' ? trim($title) : 'Mobile User';
    $insert = $db->prepare(
        'INSERT INTO chat_conversations (id, mobile_account, admin_account, title)
         VALUES (?, ?, "admin", ?)'
    );
    $insert->execute([$newId, $mobileAccount, $title]);
    return getChatConversationByMobile($db, $mobileAccount);
}

function buildChatMessage(array $row): array {
    return [
        'id'              => $row['id'],
        'conversation_id' => $row['conversation_id'],
        'sender_role'     => $row['sender_role'],
        'sender_id'       => $row['sender_id'],
        'recipient_role'  => $row['recipient_role'],
        'recipient_id'    => $row['recipient_id'],
        'body'            => $row['body'],
        'read_by_mobile'  => (bool)$row['read_by_mobile'],
        'read_by_admin'   => (bool)$row['read_by_admin'],
        'created_at'      => $row['created_at'],
    ];
}

function buildChatConversation(array $row): array {
    return [
        'id'              => $row['id'],
        'mobile_account'  => $row['mobile_account'],
        'admin_account'   => $row['admin_account'],
        'assigned_agent_id' => $row['assigned_agent_id'] ?? null,
        'assigned_at'     => $row['assigned_at'] ?? null,
        'status'          => $row['status'] ?? 'active',
        'left_at'         => $row['left_at'] ?? null,
        'closed_at'       => $row['closed_at'] ?? null,
        'assigned_agent_name' => $row['assigned_agent_name'] ?? null,
        'assigned_agent_username' => $row['assigned_agent_username'] ?? null,
        'assigned_agent_role' => $row['assigned_agent_role'] ?? null,
        'title'           => $row['title'],
        'last_message_at' => $row['last_message_at'],
        'created_at'      => $row['created_at'],
        'updated_at'      => $row['updated_at'],
    ];
}

function chatUnreadCount(PDO $db, string $conversationId, string $actor): int {
    if ($actor === 'admin') {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM chat_messages
             WHERE conversation_id = ? AND sender_role = "mobile" AND read_by_admin = 0'
        );
    } else {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM chat_messages
             WHERE conversation_id = ? AND sender_role = "admin" AND read_by_mobile = 0'
        );
    }
    $stmt->execute([$conversationId]);
    return (int)$stmt->fetchColumn();
}

function latestChatMessage(PDO $db, string $conversationId): ?array {
    $stmt = $db->prepare(
        'SELECT * FROM chat_messages WHERE conversation_id = ? ORDER BY created_at DESC, id DESC LIMIT 1'
    );
    $stmt->execute([$conversationId]);
    $row = $stmt->fetch();
    return $row ? buildChatMessage($row) : null;
}

function chatMessageCount(PDO $db, string $conversationId): int {
    $stmt = $db->prepare('SELECT COUNT(*) FROM chat_messages WHERE conversation_id = ?');
    $stmt->execute([$conversationId]);
    return (int)$stmt->fetchColumn();
}

function chatHasSupportReply(PDO $db, string $conversationId): bool {
    $stmt = $db->prepare(
        'SELECT EXISTS(
           SELECT 1 FROM chat_messages
           WHERE conversation_id = ? AND sender_role = "admin"
         )'
    );
    $stmt->execute([$conversationId]);
    return (bool)$stmt->fetchColumn();
}

function deleteEmptyChatArchives(PDO $db): void {
    $stmt = $db->prepare(
        'DELETE cc
         FROM chat_conversations cc
         WHERE cc.status <> "active"
           AND NOT EXISTS (
             SELECT 1
             FROM chat_messages cm
             WHERE cm.conversation_id = cc.id
               AND cm.body NOT IN (?, ?)
           )'
    );
    $stmt->execute([
        'Utilizatorul a parasit conversatia.',
        'Agent Support a inchis conversatia.',
    ]);
}

function buildClientActivity(array $row): array {
    $details = [];
    if (!empty($row['details'])) {
        $decoded = json_decode($row['details'], true);
        $details = is_array($decoded) ? $decoded : [];
    }

    return [
        'id'             => $row['id'],
        'client_id'      => $row['client_id'],
        'actor_user_id'  => $row['actor_user_id'],
        'actor_name'     => $row['actor_name'] ?? null,
        'actor_username' => $row['actor_username'] ?? null,
        'actor_role'     => $row['actor_role'] ?? null,
        'client_name'    => $row['client_name'] ?? null,
        'client_phone'   => $row['client_phone'] ?? null,
        'client_email'   => $row['client_email'] ?? null,
        'client_status'  => $row['client_status'] ?? null,
        'client_qr_code' => $row['client_qr_code'] ?? null,
        'action'         => $row['action'],
        'summary'        => $row['summary'],
        'details'        => $details,
        'created_at'     => $row['created_at'],
    ];
}

function getClientActivity(PDO $db, string $clientId): array {
    if (!tableExists($db, 'client_activity_logs')) {
        return [];
    }

    $stmt = $db->prepare(
        'SELECT cal.*,
                u.display_name AS actor_name,
                u.username AS actor_username,
                u.role AS actor_role
         FROM client_activity_logs cal
         LEFT JOIN app_users u ON u.id = cal.actor_user_id
         WHERE cal.client_id = ?
         ORDER BY cal.created_at DESC, cal.id DESC'
    );
    $stmt->execute([$clientId]);
    return array_map('buildClientActivity', $stmt->fetchAll());
}

function getClientParticipants(PDO $db, string $clientId): array {
    if (!tableExists($db, 'client_user_access') || !tableExists($db, 'client_activity_logs')) {
        return [];
    }

    $stmt = $db->prepare(
        "SELECT u.id, u.username, u.display_name, u.role,
                MIN(src.first_at) AS first_at,
                GROUP_CONCAT(DISTINCT src.source ORDER BY src.source SEPARATOR ',') AS sources
         FROM (
           SELECT c.owner_user_id AS user_id, 'owner' AS source, c.created_at AS first_at
           FROM clients c
           WHERE c.id = ? AND c.owner_user_id IS NOT NULL
           UNION ALL
           SELECT cua.user_id, cua.source, cua.created_at
           FROM client_user_access cua
           WHERE cua.client_id = ?
           UNION ALL
           SELECT cal.actor_user_id,
                  CASE cal.action
                    WHEN 'created' THEN 'owner'
                    WHEN 'scanned' THEN 'scan'
                    WHEN 'updated' THEN 'edit'
                    WHEN 'finalized' THEN 'edit'
                    ELSE cal.action
                  END AS source,
                  cal.created_at
           FROM client_activity_logs cal
           WHERE cal.client_id = ? AND cal.actor_user_id IS NOT NULL
         ) src
         JOIN app_users u ON u.id = src.user_id
         GROUP BY u.id, u.username, u.display_name, u.role
         ORDER BY first_at ASC"
    );
    $stmt->execute([$clientId, $clientId, $clientId]);

    return array_map(function (array $row): array {
        return [
            'id'           => $row['id'],
            'username'     => $row['username'],
            'display_name' => $row['display_name'],
            'role'         => $row['role'],
            'sources'      => array_filter(explode(',', $row['sources'] ?? '')),
            'first_at'     => $row['first_at'],
        ];
    }, $stmt->fetchAll());
}

function buildClient(array $row): array {
    global $db;
    $client = [
        'id'                  => $row['id'],
        'name'                => $row['name'],
        'phone'               => $row['phone'],
        'email'               => $row['email'],
        'status'              => $row['status'],
        'qr_code'             => $row['qr_code'],
        'qr_used'             => (bool)$row['qr_used'],
        'qr_used_at'          => $row['qr_used_at'],
        'discount_percentage' => (float)$row['discount_percentage'],
        'price'               => (float)$row['price'],
        'manopera_colaboratori' => (float)($row['manopera_colaboratori'] ?? 0),
        'valoare_piese'       => (float)($row['valoare_piese'] ?? 0),
        'alte_cheltuieli'     => (float)($row['alte_cheltuieli'] ?? 0),
        'price_edit_count'    => (int)($row['price_edit_count'] ?? 0),
        'is_finalized'        => (bool)($row['is_finalized'] ?? false),
        'notes'               => $row['notes'],
        'profile_id'          => $row['profile_id'],
        'owner_user_id'       => $row['owner_user_id'] ?? null,
        'created_at'          => $row['created_at'],
        'profiles'            => null,
    ];
    if (!empty($row['profile_id']) && !empty($row['prof_name'])) {
        $client['profiles'] = [
            'id'         => $row['profile_id'],
            'name'       => $row['prof_name'],
            'role'       => $row['prof_role'],
            'percentage' => (float)$row['prof_percentage'],
            'color'      => $row['prof_color'],
            'created_at' => $row['prof_created_at'],
        ];
    }
    $client['collaborator_costs'] = getClientCollaboratorCosts($db, $row['id']);
    $client['expense_costs'] = getClientExpenseCosts($db, $row['id']);
    $client['activity_logs'] = getClientActivity($db, $row['id']);
    $client['participants'] = getClientParticipants($db, $row['id']);
    return $client;
}

$clientJoin = 'SELECT c.*,
    p.name       AS prof_name,
    p.role       AS prof_role,
    p.percentage AS prof_percentage,
    p.color      AS prof_color,
    p.created_at AS prof_created_at
FROM clients c
LEFT JOIN profiles p ON c.profile_id = p.id';

// ─── Router ────────────────────────────────────────────────────────────────────

if ($action === 'bootstrapSystem') {
    try {
        echo json_encode(bootstrapSystem($body));
    } catch (InvalidArgumentException $error) {
        http_response_code(422);
        echo json_encode(['error' => $error->getMessage()]);
    } catch (Throwable $error) {
        http_response_code(500);
        echo json_encode(['error' => $error->getMessage()]);
    }
    exit();
}

try {
    $db = connectDatabase(DB_HOST, DB_NAME, DB_USER, DB_PASS);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Database connection failed: ' . $e->getMessage() .
            ' Pentru un server nou foloseste initializarea din aplicatia Electron.',
    ]);
    exit();
}

ensureAuthTables($db);
ensureClientOwnershipSchema($db);
ensureClientAccessSchema($db);
ensureClientActivitySchema($db);
ensurePartnerContactSchema($db);
ensureCustomExpensesSchema($db);
ensurePushNotificationTables($db);
ensureWhatsAppPredefinedMessagesTable($db);

try {

    // Chat
    if (in_array($action, [
        'getChatContacts',
        'getChatMessages',
        'acceptChat',
        'sendChatMessage',
        'markChatRead',
        'leaveChat',
        'closeChatConversation',
        'deleteChatConversation',
        'getChatUnread',
    ], true)) {
        ensureChatTables($db);
    }

    if ($action === 'login' || $action === 'adminLogin') {
        ensureAuthTables($db);
        $username = trim($body['username'] ?? '');
        $password = trim($body['password'] ?? '');
        $platform = $body['platform'] ?? 'desktop';
        if (!in_array($platform, ['desktop', 'mobile'], true)) {
            $platform = 'desktop';
        }

        $stmt = $db->prepare('SELECT * FROM app_users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        if ($user && (bool)$user['is_active'] && password_verify($password, $user['password_hash']) && userCanAccessPlatform($user, $platform)) {
            $token = createSession($db, $user['id'], $platform);
            echo json_encode([
                'success' => true,
                'token'   => $token,
                'user'    => buildAppUser($user),
            ]);
        } else {
            http_response_code(401);
            echo json_encode(['error' => 'User sau parola gresita.']);
        }

    } elseif ($action === 'logout') {
        ensureAuthTables($db);
        $token = currentAuthToken($body);
        if ($token !== '') {
            $stmt = $db->prepare('DELETE FROM app_sessions WHERE token_hash = ?');
            $stmt->execute([hash('sha256', $token)]);
        }
        echo json_encode(['success' => true]);

    } elseif ($action === 'registerPushToken') {
        $me = requireAuth($db, $body);
        $pushToken = trim((string)($body['push_token'] ?? ''));
        $platform = trim((string)($body['platform'] ?? 'android'));
        if (!isExpoPushToken($pushToken)) {
            http_response_code(422);
            echo json_encode(['error' => 'Push token invalid.']);
            exit();
        }
        if (!in_array($platform, ['android', 'ios', 'mobile'], true)) {
            $platform = 'android';
        }
        $stmt = $db->prepare(
            'INSERT INTO app_push_tokens (id, user_id, token, platform, last_seen_at)
             VALUES (?, ?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE
               user_id = VALUES(user_id),
               platform = VALUES(platform),
               last_seen_at = NOW(),
               updated_at = NOW()'
        );
        $stmt->execute([uuid(), $me['id'], $pushToken, $platform]);
        echo json_encode(['success' => true]);

    } elseif ($action === 'unregisterPushToken') {
        $me = requireAuth($db, $body);
        $pushToken = trim((string)($body['push_token'] ?? ''));
        if ($pushToken !== '') {
            $stmt = $db->prepare('DELETE FROM app_push_tokens WHERE user_id = ? AND token = ?');
            $stmt->execute([$me['id'], $pushToken]);
        }
        echo json_encode(['success' => true]);

    } elseif ($action === 'getCurrentUser') {
        $user = requireAuth($db, $body);
        echo json_encode(buildAppUser($user));

    } elseif ($action === 'updateOwnProfile') {
        $user = requireAuth($db, $body, 'desktop');
        if (($user['role'] ?? '') !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Profilul poate fi modificat doar de administrator.']);
            exit();
        }
        $displayName = trim((string)($body['display_name'] ?? ''));
        $password = trim((string)($body['password'] ?? ''));
        if ($displayName === '') {
            http_response_code(422);
            echo json_encode(['error' => 'Numele afisat este obligatoriu.']);
            exit();
        }
        if ($password !== '' && strlen($password) < 4) {
            http_response_code(422);
            echo json_encode(['error' => 'Parola trebuie sa aiba minimum 4 caractere.']);
            exit();
        }
        if ($password !== '') {
            $stmt = $db->prepare('UPDATE app_users SET display_name = ?, password_hash = ? WHERE id = ?');
            $stmt->execute([$displayName, password_hash($password, PASSWORD_DEFAULT), $user['id']]);
        } else {
            $stmt = $db->prepare('UPDATE app_users SET display_name = ? WHERE id = ?');
            $stmt->execute([$displayName, $user['id']]);
        }
        $read = $db->prepare('SELECT * FROM app_users WHERE id = ?');
        $read->execute([$user['id']]);
        echo json_encode(buildAppUser($read->fetch()));

    } elseif ($action === 'getUsers') {
        requireAdmin($db, $body);
        $stmt = $db->query('SELECT * FROM app_users ORDER BY created_at DESC');
        echo json_encode(array_map('buildAppUser', $stmt->fetchAll()));

    } elseif ($action === 'getSystemDatabaseInfo') {
        requireAdmin($db, $body);
        echo json_encode([
            'api_url' => publicApiBaseUrl(),
            'api_key' => API_KEY,
            'db_host' => DB_HOST,
            'db_name' => DB_NAME,
            'db_user' => DB_USER,
            'db_pass' => DB_PASS,
            'db_password_saved' => DB_PASS !== '',
            'schema_file' => is_file(__DIR__ . '/schema.sql') ? 'schema.sql' : null,
            'config_file_saved' => is_file(SERVER_CONFIG_FILE),
        ]);

    } elseif ($action === 'saveSystemDatabaseInfo') {
        requireAdmin($db, $body);

        $apiKey = trim((string)($body['api_key'] ?? API_KEY));
        $dbHost = trim((string)($body['db_host'] ?? ''));
        $dbName = trim((string)($body['db_name'] ?? ''));
        $dbUser = trim((string)($body['db_user'] ?? ''));
        $dbPassInput = (string)($body['db_pass'] ?? '');
        $keepDbPass = !empty($body['keep_db_pass']) && $dbPassInput === '';
        $dbPass = $keepDbPass ? DB_PASS : $dbPassInput;
        $runSchema = !empty($body['run_schema']);

        if ($apiKey === '' || $dbHost === '' || $dbName === '' || $dbUser === '') {
            http_response_code(422);
            echo json_encode(['error' => 'API key, DB host, DB name si DB user sunt obligatorii.']);
            exit();
        }

        $databaseResult = prepareSystemDatabase(
            $dbHost,
            $dbName,
            $dbUser,
            $dbPass,
            $runSchema
        );

        writeServerRuntimeConfig([
            'api_key' => $apiKey,
            'db_host' => $dbHost,
            'db_name' => $dbName,
            'db_user' => $dbUser,
            'db_pass' => $dbPass,
        ]);

        echo json_encode([
            'success' => true,
            'database_created' => $databaseResult['database_created'],
            'schema_ran' => $databaseResult['schema_ran'],
            'schema_statements' => $databaseResult['schema_statements'],
            'default_admin_ready' => $databaseResult['default_admin_ready'],
            'config_file_saved' => true,
            'target_database' => $dbName,
            'api_key_changed' => $apiKey !== API_KEY,
            'message' => 'Configuratia a fost salvata. Aplicatiile vor folosi noua baza la urmatoarea cerere.',
        ]);

    } elseif ($action === 'createUser') {
        requireAdmin($db, $body);
        $username = trim($body['username'] ?? '');
        $password = trim($body['password'] ?? '');
        $displayName = trim($body['display_name'] ?? $username);
        $role = $body['role'] ?? 'user';
        if ($username === '' || $password === '') {
            http_response_code(422);
            echo json_encode(['error' => 'Userul si parola sunt obligatorii.']);
            exit();
        }
        $duplicateStmt = $db->prepare('SELECT COUNT(*) FROM app_users WHERE LOWER(username) = LOWER(?)');
        $duplicateStmt->execute([$username]);
        if ((int)$duplicateStmt->fetchColumn() > 0) {
            http_response_code(422);
            echo json_encode(['error' => 'Username-ul exista deja. Alege alt username.']);
            exit();
        }
        if (!in_array($role, ['admin', 'manager', 'user'], true)) {
            $role = 'user';
        }
        $platformAccess = $body['platform_access'] ?? ($role === 'admin' ? 'desktop' : 'mobile');
        if (!in_array($platformAccess, ['desktop', 'mobile', 'both'], true)) {
            http_response_code(422);
            echo json_encode(['error' => 'Accesul platforma poate fi Mobile, Desktop sau Desktop + Mobil.']);
            exit();
        }
        if ($role === 'admin' && !in_array($platformAccess, ['desktop', 'both'], true)) {
            http_response_code(422);
            echo json_encode(['error' => 'Conturile admin pot avea acces pe Desktop sau Desktop + Mobil.']);
            exit();
        }
        $supportChatAccess = !empty($body['support_chat_access']) ? 1 : 0;
        $clientEditAccess = $role === 'user' && !empty($body['client_edit_access']) ? 1 : 0;
        $isActive = !empty($body['is_active']) ? 1 : 0;
        $newId = uuid();
        $stmt = $db->prepare(
            'INSERT INTO app_users (id, username, password_hash, display_name, role, platform_access, support_chat_access, client_edit_access, is_active)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $newId,
            $username,
            password_hash($password, PASSWORD_DEFAULT),
            $displayName !== '' ? $displayName : $username,
            $role,
            $platformAccess,
            $supportChatAccess,
            $clientEditAccess,
            $isActive,
        ]);
        $read = $db->prepare('SELECT * FROM app_users WHERE id = ?');
        $read->execute([$newId]);
        echo json_encode(buildAppUser($read->fetch()));

    } elseif ($action === 'updateUser') {
        requireAdmin($db, $body);
        $userId = $id ?: ($body['id'] ?? '');
        $displayName = trim($body['display_name'] ?? '');
        $password = trim($body['password'] ?? '');
        $username = trim($body['username'] ?? '');
        $targetStmt = $db->prepare('SELECT * FROM app_users WHERE id = ? LIMIT 1');
        $targetStmt->execute([$userId]);
        $targetUser = $targetStmt->fetch();
        $isProtectedAdmin = $targetUser && strtolower((string)($targetUser['username'] ?? '')) === 'admin';

        if ($username !== '') {
            $duplicateStmt = $db->prepare('SELECT COUNT(*) FROM app_users WHERE LOWER(username) = LOWER(?) AND id <> ?');
            $duplicateStmt->execute([$username, $userId]);
            if ((int)$duplicateStmt->fetchColumn() > 0) {
                http_response_code(422);
                echo json_encode(['error' => 'Username-ul exista deja. Alege alt username.']);
                exit();
            }
        }

        if ($isProtectedAdmin) {
            if ($password !== '') {
                $stmt = $db->prepare(
                    'UPDATE app_users
                     SET display_name=?, role="admin", platform_access="both",
                         support_chat_access=1, client_edit_access=1, is_active=1, password_hash=?
                     WHERE id=?'
                );
                $stmt->execute([$displayName, password_hash($password, PASSWORD_DEFAULT), $userId]);
            } else {
                $stmt = $db->prepare(
                    'UPDATE app_users
                     SET display_name=?, role="admin", platform_access="both",
                         support_chat_access=1, client_edit_access=1, is_active=1
                     WHERE id=?'
                );
                $stmt->execute([$displayName, $userId]);
            }
            $read = $db->prepare('SELECT * FROM app_users WHERE id = ?');
            $read->execute([$userId]);
            echo json_encode(buildAppUser($read->fetch()));
            exit();
        }

        $role = $body['role'] ?? 'user';
        $isActive = !empty($body['is_active']) ? 1 : 0;
        if (!in_array($role, ['admin', 'manager', 'user'], true)) {
            $role = 'user';
        }
        $platformAccess = $body['platform_access'] ?? ($role === 'admin' ? 'desktop' : 'mobile');
        if (!in_array($platformAccess, ['desktop', 'mobile', 'both'], true)) {
            http_response_code(422);
            echo json_encode(['error' => 'Accesul platforma poate fi Mobile, Desktop sau Desktop + Mobil.']);
            exit();
        }
        if ($role === 'admin' && !in_array($platformAccess, ['desktop', 'both'], true)) {
            http_response_code(422);
            echo json_encode(['error' => 'Conturile admin pot avea acces pe Desktop sau Desktop + Mobil.']);
            exit();
        }
        $supportChatAccess = !empty($body['support_chat_access']) ? 1 : 0;
        $clientEditAccess = $role === 'user' && !empty($body['client_edit_access']) ? 1 : 0;
        if ($password !== '') {
            $stmt = $db->prepare(
                'UPDATE app_users
                 SET display_name=?, role=?, platform_access=?, support_chat_access=?, client_edit_access=?, is_active=?, password_hash=?
                 WHERE id=?'
            );
            $stmt->execute([$displayName, $role, $platformAccess, $supportChatAccess, $clientEditAccess, $isActive, password_hash($password, PASSWORD_DEFAULT), $userId]);
        } else {
            $stmt = $db->prepare(
                'UPDATE app_users
                 SET display_name=?, role=?, platform_access=?, support_chat_access=?, client_edit_access=?, is_active=?
                 WHERE id=?'
            );
            $stmt->execute([$displayName, $role, $platformAccess, $supportChatAccess, $clientEditAccess, $isActive, $userId]);
        }
        if (!$supportChatAccess || !$isActive) {
            releaseChatAssignmentsForUser($db, $userId);
        }
        $read = $db->prepare('SELECT * FROM app_users WHERE id = ?');
        $read->execute([$userId]);
        echo json_encode(buildAppUser($read->fetch()));

    } elseif ($action === 'deleteUser') {
        $me = requireAdmin($db, $body);
        $userId = $id ?: ($body['id'] ?? '');
        if ($userId === $me['id']) {
            http_response_code(422);
            echo json_encode(['error' => 'Nu iti poti sterge propriul cont.']);
            exit();
        }
        $read = $db->prepare('SELECT * FROM app_users WHERE id = ? LIMIT 1');
        $read->execute([$userId]);
        $targetUser = $read->fetch();
        if ($targetUser && strtolower((string)($targetUser['username'] ?? '')) === 'admin') {
            http_response_code(422);
            echo json_encode(['error' => 'Userul principal "admin" nu poate fi sters.']);
            exit();
        }
        releaseChatAssignmentsForUser($db, $userId);
        $stmt = $db->prepare('DELETE FROM app_users WHERE id = ?');
        $stmt->execute([$userId]);
        echo json_encode(['success' => true]);

    } elseif ($action === 'getChatContacts') {
        $actor = $_GET['actor'] ?? 'mobile';
        $isAgentActor = in_array($actor, ['admin', 'agent'], true);
        if ($isAgentActor) {
            $agent = requireSupportChatAgent($db, $body);
            $chatSupervisor = isChatSupervisor($agent);
            ensureChatTables($db);
            deleteEmptyChatArchives($db);
            $assignmentFilter = $chatSupervisor
                ? ''
                : ' AND (cc.assigned_agent_id IS NULL OR cc.assigned_agent_id = ?)';
            $stmt = $db->prepare(
                "SELECT cc.*,
                        requester.display_name AS requester_name,
                        requester.username AS requester_username,
                        requester.role AS requester_role,
                        assigned.display_name AS assigned_agent_name,
                        assigned.username AS assigned_agent_username,
                        assigned.role AS assigned_agent_role
                 FROM chat_conversations cc
                 JOIN app_users requester
                   ON requester.id = cc.mobile_account
                  AND requester.is_active = 1
                  AND requester.support_chat_access = 0
                 LEFT JOIN app_users assigned ON assigned.id = cc.assigned_agent_id
                 WHERE EXISTS (
                   SELECT 1 FROM chat_messages cm
                   WHERE cm.conversation_id = cc.id
                     AND cm.body NOT IN ('Utilizatorul a parasit conversatia.', 'Agent Support a inchis conversatia.')
                 )
                   $assignmentFilter
                 ORDER BY COALESCE(cc.last_message_at, cc.created_at) DESC"
            );
            $stmt->execute($chatSupervisor ? [] : [$agent['id']]);
            $contacts = [];
            foreach ($stmt->fetchAll() as $conversation) {
                $inactive = ($conversation['status'] ?? 'active') !== 'active';
                $contacts[] = [
                    'id'                        => $conversation['id'],
                    'mobile_id'                 => $conversation['mobile_account'],
                    'name'                      => $conversation['requester_name'],
                    'username'                  => $conversation['requester_username'],
                    'role'                      => $conversation['requester_role'],
                    'conversation_id'           => $conversation['id'],
                    'last_message_at'           => $conversation['last_message_at'],
                    'unread_count'              => chatUnreadCount($db, $conversation['id'], 'admin'),
                    'latest_message'            => latestChatMessage($db, $conversation['id']),
                    'status'                    => $conversation['status'] ?? 'active',
                    'left_at'                   => $conversation['left_at'] ?? null,
                    'closed_at'                 => $conversation['closed_at'] ?? null,
                    'assigned_agent_id'         => $conversation['assigned_agent_id'] ?? null,
                    'assigned_agent_name'       => $conversation['assigned_agent_name'] ?? null,
                    'assigned_agent_username'   => $conversation['assigned_agent_username'] ?? null,
                    'assigned_agent_role'       => $conversation['assigned_agent_role'] ?? null,
                    'can_reply'                 => !$inactive && (
                        $chatSupervisor
                        || (($conversation['assigned_agent_id'] ?? null) === $agent['id'])
                    ),
                ];
            }
            echo json_encode($contacts);
        } else {
            $user = requireChatRequester($db, $body);
            $conversation = getOrCreateChatConversation($db, $user['id'], $user['display_name']);
            $agentName = trim((string)($conversation['assigned_agent_name'] ?? ''));
            echo json_encode([[
                'id'                        => 'admin',
                'name'                      => $agentName !== '' ? $agentName . ' (Agent Support)' : 'Support',
                'role'                      => 'admin',
                'conversation_id'           => $conversation['id'],
                'last_message_at'           => $conversation['last_message_at'],
                'unread_count'              => chatUnreadCount($db, $conversation['id'], 'mobile'),
                'latest_message'            => latestChatMessage($db, $conversation['id']),
                'status'                    => $conversation['status'] ?? 'active',
                'left_at'                   => $conversation['left_at'] ?? null,
                'closed_at'                 => $conversation['closed_at'] ?? null,
                'assigned_agent_id'         => $conversation['assigned_agent_id'] ?? null,
                'assigned_agent_name'       => $conversation['assigned_agent_name'] ?? null,
                'assigned_agent_username'   => $conversation['assigned_agent_username'] ?? null,
                'assigned_agent_role'       => $conversation['assigned_agent_role'] ?? null,
            ]]);
        }

    } elseif ($action === 'getChatMessages') {
        $actor = $_GET['actor'] ?? 'mobile';
        $isAgentActor = in_array($actor, ['admin', 'agent'], true);
        if ($isAgentActor) {
            $agent = requireSupportChatAgent($db, $body);
            $chatSupervisor = isChatSupervisor($agent);
            $conversationId = $_GET['conversationId'] ?? ($_GET['mobileId'] ?? '');
            $conversation = getChatConversationById($db, $conversationId);
            $mobileUser = $conversation ? getChatRequesterById($db, $conversation['mobile_account']) : null;
            if (!$conversation || !$mobileUser) {
                http_response_code(404);
                echo json_encode(['error' => 'Conversatie inexistenta.']);
                exit();
            }
            if (!$chatSupervisor
                && !empty($conversation['assigned_agent_id'])
                && $conversation['assigned_agent_id'] !== $agent['id']) {
                http_response_code(403);
                echo json_encode(['error' => 'Conversatia este preluata de alt agent.']);
                exit();
            }
        } else {
            $user = requireChatRequester($db, $body);
            $conversation = getOrCreateChatConversation($db, $user['id'], $user['display_name']);
        }

        $stmt = $db->prepare(
            'SELECT * FROM chat_messages
             WHERE conversation_id = ?
             ORDER BY created_at ASC, id ASC'
        );
        $stmt->execute([$conversation['id']]);
        echo json_encode([
            'conversation' => buildChatConversation($conversation),
            'messages'     => array_map('buildChatMessage', $stmt->fetchAll()),
        ]);

    } elseif ($action === 'acceptChat') {
        $agent = requireSupportChatAgent($db, $body);
        $conversationId = $body['conversation_id'] ?? ($body['mobile_id'] ?? '');
        $conversation = getChatConversationById($db, $conversationId);
        if (!$conversation) {
            http_response_code(404);
            echo json_encode(['error' => 'Conversatie inexistenta.']);
            exit();
        }
        if (($conversation['status'] ?? 'active') !== 'active') {
            http_response_code(409);
            echo json_encode(['error' => 'Conversatia este inchisa.']);
            exit();
        }
        if (!empty($conversation['assigned_agent_id']) && $conversation['assigned_agent_id'] !== $agent['id']) {
            http_response_code(409);
            echo json_encode(['error' => 'Conversatia a fost deja preluata de alt agent.']);
            exit();
        }
        $acceptStmt = $db->prepare(
            'UPDATE chat_conversations
             SET assigned_agent_id = ?, admin_account = ?, assigned_at = COALESCE(assigned_at, NOW()), updated_at = NOW()
             WHERE id = ? AND (assigned_agent_id IS NULL OR assigned_agent_id = ?)'
        );
        $acceptStmt->execute([$agent['id'], $agent['username'], $conversation['id'], $agent['id']]);
        if ($acceptStmt->rowCount() === 0) {
            http_response_code(409);
            echo json_encode(['error' => 'Conversatia a fost deja preluata de alt agent.']);
            exit();
        }
        echo json_encode(buildChatConversation(getChatConversationById($db, $conversation['id'])));

    } elseif ($action === 'sendChatMessage') {
        $actor = $body['actor'] ?? 'mobile';
        $isAgentActor = in_array($actor, ['admin', 'agent'], true);
        $text = trim($body['body'] ?? '');
        if ($text === '') {
            http_response_code(422);
            echo json_encode(['error' => 'Mesajul nu poate fi gol.']);
            exit();
        }

        if ($isAgentActor) {
            $adminUser = requireSupportChatAgent($db, $body);
            $chatSupervisor = isChatSupervisor($adminUser);
            $conversationId = $body['conversation_id'] ?? ($body['mobile_id'] ?? '');
            $conversation = getChatConversationById($db, $conversationId);
            $mobileUser = $conversation ? getChatRequesterById($db, $conversation['mobile_account']) : null;
            if (!$conversation || !$mobileUser) {
                http_response_code(404);
                echo json_encode(['error' => 'Conversatie inexistenta.']);
                exit();
            }
            if (($conversation['status'] ?? 'active') !== 'active') {
                http_response_code(409);
                echo json_encode(['error' => 'Conversatia este inchisa.']);
                exit();
            }
            $senderRole = 'admin';
            $senderId = $adminUser['id'];
            $recipientRole = 'mobile';
            $recipientId = $mobileUser['id'];
            $readByMobile = 0;
            $readByAdmin = 1;
            if (!$chatSupervisor && empty($conversation['assigned_agent_id'])) {
                http_response_code(422);
                echo json_encode(['error' => 'Accepta conversatia inainte sa raspunzi.']);
                exit();
            }
            if (!$chatSupervisor && $conversation['assigned_agent_id'] !== $adminUser['id']) {
                http_response_code(403);
                echo json_encode(['error' => 'Conversatia este preluata de alt agent.']);
                exit();
            }
        } else {
            $mobileUser = requireChatRequester($db, $body);
            $senderRole = 'mobile';
            $senderId = $mobileUser['id'];
            $recipientRole = 'admin';
            $recipientId = 'admin';
            $readByMobile = 1;
            $readByAdmin = 0;
            $conversation = getOrCreateChatConversation($db, $mobileUser['id'], $mobileUser['display_name']);
        }

        $messageId = uuid();
        $stmt = $db->prepare(
            'INSERT INTO chat_messages
             (id, conversation_id, sender_role, sender_id, recipient_role, recipient_id, body, read_by_mobile, read_by_admin)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $messageId,
            $conversation['id'],
            $senderRole,
            $senderId,
            $recipientRole,
            $recipientId,
            $text,
            $readByMobile,
            $readByAdmin,
        ]);
        $db->prepare('UPDATE chat_conversations SET last_message_at = NOW(), updated_at = NOW() WHERE id = ?')
            ->execute([$conversation['id']]);

        $readStmt = $db->prepare('SELECT * FROM chat_messages WHERE id = ?');
        $readStmt->execute([$messageId]);
        $savedMessage = buildChatMessage($readStmt->fetch());

        try {
            $pushRecipients = pushRecipientIdsForChat($db, $recipientRole, $recipientId, $conversation);
            $pushTitle = $recipientRole === 'mobile'
                ? 'Mesaj nou de la Support'
                : 'Mesaj nou de la ' . ($mobileUser['display_name'] ?? 'client');
            sendPushNotificationToUsers($db, $pushRecipients, $pushTitle, $text, [
                'screen' => 'chat',
                'conversationId' => $conversation['id'],
                'messageId' => $messageId,
            ]);
        } catch (Throwable $pushError) {
            // Mesajul ramane trimis chiar daca furnizorul de push nu raspunde.
        }

        echo json_encode($savedMessage);

    } elseif ($action === 'markChatRead') {
        $actor = $body['actor'] ?? 'mobile';
        $isAgentActor = in_array($actor, ['admin', 'agent'], true);
        if ($isAgentActor) {
            $agent = requireSupportChatAgent($db, $body);
            $chatSupervisor = isChatSupervisor($agent);
            $conversationId = $body['conversation_id'] ?? ($body['mobile_id'] ?? '');
            $conversation = getChatConversationById($db, $conversationId);
            if (!$conversation) {
                http_response_code(404);
                echo json_encode(['error' => 'Conversatie inexistenta.']);
                exit();
            }
            if (!$chatSupervisor
                && !empty($conversation['assigned_agent_id'])
                && $conversation['assigned_agent_id'] !== $agent['id']) {
                echo json_encode(['success' => true]);
                exit();
            }
        } else {
            $mobileUser = requireChatRequester($db, $body);
            $conversation = getOrCreateChatConversation($db, $mobileUser['id'], $mobileUser['display_name']);
        }
        if ($isAgentActor) {
            $stmt = $db->prepare(
                'UPDATE chat_messages SET read_by_admin = 1
                 WHERE conversation_id = ? AND sender_role = "mobile"'
            );
        } else {
            $stmt = $db->prepare(
                'UPDATE chat_messages SET read_by_mobile = 1
                 WHERE conversation_id = ? AND sender_role = "admin"'
            );
        }
        $stmt->execute([$conversation['id']]);
        echo json_encode(['success' => true]);

    } elseif ($action === 'leaveChat') {
        $mobileUser = requireChatRequester($db, $body);
        $conversation = getOrCreateChatConversation($db, $mobileUser['id'], $mobileUser['display_name']);
        if (!chatHasSupportReply($db, $conversation['id'])) {
            http_response_code(409);
            echo json_encode(['error' => 'Conversatia poate fi parasita dupa primul raspuns de la Agent Support.']);
            exit();
        }
        if (chatMessageCount($db, $conversation['id']) === 0) {
            $db->prepare(
                'UPDATE chat_conversations
                 SET admin_account = "admin", assigned_agent_id = NULL, assigned_at = NULL,
                     last_message_at = NULL, updated_at = NOW()
                 WHERE id = ? AND status = "active"'
            )->execute([$conversation['id']]);
            echo json_encode([
                'success' => true,
                'conversation' => buildChatConversation(getChatConversationById($db, $conversation['id'])),
            ]);
            exit();
        }
        $db->beginTransaction();
        try {
            $messageId = uuid();
            $db->prepare(
                'INSERT INTO chat_messages
                 (id, conversation_id, sender_role, sender_id, recipient_role, recipient_id, body, read_by_mobile, read_by_admin)
                 VALUES (?, ?, "mobile", ?, "admin", "admin", ?, 1, 0)'
            )->execute([
                $messageId,
                $conversation['id'],
                $mobileUser['id'],
                'Utilizatorul a parasit conversatia.',
            ]);
            $db->prepare(
                'UPDATE chat_conversations
                 SET status = "left", left_at = NOW(), last_message_at = NOW(), updated_at = NOW()
                 WHERE id = ? AND status = "active"'
            )->execute([$conversation['id']]);
            $newConversationId = uuid();
            $db->prepare(
                'INSERT INTO chat_conversations (id, mobile_account, admin_account, title, status)
                 VALUES (?, ?, "admin", ?, "active")'
            )->execute([$newConversationId, $mobileUser['id'], $mobileUser['display_name']]);
            $db->commit();
            try {
                $pushRecipients = pushRecipientIdsForChat($db, 'admin', 'admin', $conversation);
                sendPushNotificationToUsers($db, $pushRecipients, 'Conversatie parasita', 'Utilizatorul a parasit conversatia.', [
                    'screen' => 'chat',
                    'conversationId' => $conversation['id'],
                    'messageId' => $messageId,
                ]);
            } catch (Throwable $pushError) {
            }
            echo json_encode([
                'success' => true,
                'conversation' => buildChatConversation(getChatConversationById($db, $newConversationId)),
            ]);
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }

    } elseif ($action === 'closeChatConversation') {
        $agent = requireSupportChatAgent($db, $body);
        $conversationId = $body['conversation_id'] ?? '';
        $conversation = getChatConversationById($db, $conversationId);
        if (!$conversation) {
            http_response_code(404);
            echo json_encode(['error' => 'Conversatie inexistenta.']);
            exit();
        }
        if (($conversation['status'] ?? 'active') !== 'active') {
            http_response_code(409);
            echo json_encode(['error' => 'Conversatia este deja inchisa.']);
            exit();
        }
        if (!isChatSupervisor($agent)
            && (empty($conversation['assigned_agent_id']) || $conversation['assigned_agent_id'] !== $agent['id'])) {
            http_response_code(403);
            echo json_encode(['error' => 'Doar agentul care a preluat conversatia o poate inchide.']);
            exit();
        }

        $db->beginTransaction();
        try {
            $messageId = uuid();
            $db->prepare(
                'INSERT INTO chat_messages
                 (id, conversation_id, sender_role, sender_id, recipient_role, recipient_id, body, read_by_mobile, read_by_admin)
                 VALUES (?, ?, "admin", ?, "mobile", ?, ?, 0, 1)'
            )->execute([
                $messageId,
                $conversation['id'],
                $agent['id'],
                $conversation['mobile_account'],
                'Agent Support a inchis conversatia.',
            ]);
            $db->prepare(
                'UPDATE chat_conversations
                 SET status = "closed", closed_at = NOW(), last_message_at = NOW(), updated_at = NOW()
                 WHERE id = ? AND status = "active"'
            )->execute([$conversation['id']]);
            $newConversationId = uuid();
            $db->prepare(
                'INSERT INTO chat_conversations (id, mobile_account, admin_account, title, status)
                 VALUES (?, ?, "admin", ?, "active")'
            )->execute([$newConversationId, $conversation['mobile_account'], $conversation['title']]);
            $db->commit();
            try {
                sendPushNotificationToUsers($db, [$conversation['mobile_account']], 'Conversatie inchisa', 'Agent Support a inchis conversatia.', [
                    'screen' => 'chat',
                    'conversationId' => $conversation['id'],
                    'messageId' => $messageId,
                ]);
            } catch (Throwable $pushError) {
            }
            echo json_encode([
                'success' => true,
                'conversation' => buildChatConversation(getChatConversationById($db, $newConversationId)),
            ]);
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }

    } elseif ($action === 'deleteChatConversation') {
        $agent = requireSupportChatAgent($db, $body);
        $conversationId = $body['conversation_id'] ?? ($_GET['conversationId'] ?? '');
        $conversation = getChatConversationById($db, $conversationId);
        if (!$conversation) {
            http_response_code(404);
            echo json_encode(['error' => 'Conversatie inexistenta.']);
            exit();
        }
        if (($conversation['status'] ?? 'active') === 'active') {
            http_response_code(409);
            echo json_encode(['error' => 'Doar conversatiile inchise pot fi sterse.']);
            exit();
        }
        if (!isChatSupervisor($agent)
            && !empty($conversation['assigned_agent_id'])
            && $conversation['assigned_agent_id'] !== $agent['id']) {
            http_response_code(403);
            echo json_encode(['error' => 'Conversatia este preluata de alt agent.']);
            exit();
        }
        $stmt = $db->prepare('DELETE FROM chat_conversations WHERE id = ? AND status <> "active"');
        $stmt->execute([$conversationId]);
        echo json_encode(['success' => $stmt->rowCount() > 0]);

    } elseif ($action === 'getChatUnread') {
        $actor = $_GET['actor'] ?? 'mobile';
        $isAgentActor = in_array($actor, ['admin', 'agent'], true);
        if ($isAgentActor) {
            $agent = requireSupportChatAgent($db, $body);
            ensureChatTables($db);
            deleteEmptyChatArchives($db);
            $chatSupervisor = isChatSupervisor($agent);
            $filter = $chatSupervisor ? '' : ' AND (cc.assigned_agent_id IS NULL OR cc.assigned_agent_id = ?)';
            $params = $chatSupervisor ? [] : [$agent['id']];
            $countStmt = $db->prepare(
                'SELECT COUNT(DISTINCT cm.conversation_id)
                 FROM chat_messages cm
                 JOIN chat_conversations cc ON cc.id = cm.conversation_id
                 JOIN app_users au
                  ON au.id = cc.mobile_account
                  AND au.is_active = 1
                  AND au.support_chat_access = 0
                 WHERE cm.sender_role = "mobile" AND cm.read_by_admin = 0' . $filter
            );
            $countStmt->execute($params);
            $latestStmt = $db->prepare(
                'SELECT cm.*
                 FROM chat_messages cm
                 JOIN chat_conversations cc ON cc.id = cm.conversation_id
                 JOIN app_users au
                  ON au.id = cc.mobile_account
                  AND au.is_active = 1
                  AND au.support_chat_access = 0
                 WHERE cm.sender_role = "mobile" AND cm.read_by_admin = 0' . $filter . '
                 ORDER BY cm.created_at DESC, cm.id DESC
                 LIMIT 1'
            );
            $latestStmt->execute($params);
            $latest = $latestStmt->fetch();
            echo json_encode([
                'unread_count'   => (int)$countStmt->fetchColumn(),
                'latest_message' => $latest ? buildChatMessage($latest) : null,
            ]);
        } else {
            $mobileUser = requireChatRequester($db, $body);
            $conversation = getOrCreateChatConversation($db, $mobileUser['id'], $mobileUser['display_name']);
            echo json_encode([
                'unread_count'   => chatUnreadCount($db, $conversation['id'], 'mobile'),
                'latest_message' => latestChatMessage($db, $conversation['id']),
            ]);
        }

    // ── Clients ──────────────────────────────────────────────────────────────

    } elseif ($action === 'sendWhatsAppQr') {
        requireAuth($db, $body, 'desktop');
        $phone = normalizeWhatsAppPhone((string)($body['phone'] ?? ''));
        $caption = trim((string)($body['caption'] ?? ''));
        $imageDataUrl = (string)($body['image_data_url'] ?? '');

        if ($phone === '' || strlen($phone) < 10 || strlen($phone) > 15) {
            http_response_code(422);
            echo json_encode(['error' => 'Numarul de telefon al clientului nu este valid pentru WhatsApp.']);
            exit();
        }
        if (!str_starts_with($imageDataUrl, 'data:image/png;base64,')) {
            http_response_code(422);
            echo json_encode(['error' => 'Imaginea QR nu este un PNG valid.']);
            exit();
        }

        $imageBytes = base64_decode(substr($imageDataUrl, strlen('data:image/png;base64,')), true);
        if ($imageBytes === false || strlen($imageBytes) < 100 || strlen($imageBytes) > 5 * 1024 * 1024) {
            http_response_code(422);
            echo json_encode(['error' => 'Imaginea QR este invalida sau prea mare.']);
            exit();
        }

        $tempPath = tempnam(sys_get_temp_dir(), 'gtrots_qr_');
        if ($tempPath === false || file_put_contents($tempPath, $imageBytes) === false) {
            throw new RuntimeException('Imaginea QR nu a putut fi pregatita pe server.');
        }

        try {
            $upload = whatsappApiRequest(
                WHATSAPP_PHONE_NUMBER_ID . '/media',
                [
                    'messaging_product' => 'whatsapp',
                    'type' => 'image/png',
                    'file' => new CURLFile($tempPath, 'image/png', 'gtrots_qr.png'),
                ],
                true
            );
            $mediaId = (string)($upload['id'] ?? '');
            if ($mediaId === '') {
                throw new RuntimeException('WhatsApp nu a returnat identificatorul imaginii QR.');
            }

            $imagePayload = ['id' => $mediaId];
            if ($caption !== '') {
                $imagePayload['caption'] = function_exists('mb_substr')
                    ? mb_substr($caption, 0, 1024)
                    : substr($caption, 0, 1024);
            }

            $sent = whatsappApiRequest(
                WHATSAPP_PHONE_NUMBER_ID . '/messages',
                [
                    'messaging_product' => 'whatsapp',
                    'recipient_type' => 'individual',
                    'to' => $phone,
                    'type' => 'image',
                    'image' => $imagePayload,
                ]
            );
            echo json_encode([
                'success' => true,
                'message_id' => $sent['messages'][0]['id'] ?? null,
            ]);
        } finally {
            if (is_file($tempPath)) {
                unlink($tempPath);
            }
        }

    } elseif ($action === 'getWhatsAppPredefinedMessages') {
        $actor = requireAuth($db, $body);
        $targetUserId = trim((string)($_GET['targetUserId'] ?? ''));
        if ($targetUserId !== '' && ($actor['role'] ?? '') !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Doar administratorul poate vedea mesajele altui utilizator.']);
            exit();
        }
        $ownerUserId = $targetUserId !== '' ? $targetUserId : $actor['id'];
        $stmt = $db->prepare(
            'SELECT m.*, u.display_name AS created_by_name
             FROM whatsapp_predefined_messages m
             LEFT JOIN app_users u ON u.id = m.created_by
             WHERE m.created_by = ?
             ORDER BY m.updated_at DESC, m.created_at DESC'
        );
        $stmt->execute([$ownerUserId]);
        echo json_encode($stmt->fetchAll());

    } elseif ($action === 'createWhatsAppPredefinedMessage') {
        $actor = requireAuth($db, $body);
        $targetUserId = trim((string)($body['target_user_id'] ?? ''));
        if ($targetUserId !== '' && ($actor['role'] ?? '') !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Doar administratorul poate adauga mesaje altui utilizator.']);
            exit();
        }
        $ownerUserId = $targetUserId !== '' ? $targetUserId : $actor['id'];
        $title = trim((string)($body['title'] ?? ''));
        $message = trim((string)($body['body'] ?? ''));
        if ($title === '' || $message === '') {
            http_response_code(422);
            echo json_encode(['error' => 'Titlul si mesajul sunt obligatorii.']);
            exit();
        }
        $newId = uuid();
        $stmt = $db->prepare(
            'INSERT INTO whatsapp_predefined_messages (id, title, body, created_by)
             VALUES (?, ?, ?, ?)'
        );
        $stmt->execute([$newId, mb_substr($title, 0, 120), $message, $ownerUserId]);
        $read = $db->prepare(
            'SELECT m.*, u.display_name AS created_by_name
             FROM whatsapp_predefined_messages m
             LEFT JOIN app_users u ON u.id = m.created_by
             WHERE m.id = ?'
        );
        $read->execute([$newId]);
        echo json_encode($read->fetch());

    } elseif ($action === 'updateWhatsAppPredefinedMessage') {
        $actor = requireAuth($db, $body);
        $targetUserId = trim((string)($body['target_user_id'] ?? ''));
        if ($targetUserId !== '' && ($actor['role'] ?? '') !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Doar administratorul poate edita mesajele altui utilizator.']);
            exit();
        }
        $ownerUserId = $targetUserId !== '' ? $targetUserId : $actor['id'];
        $messageId = $id ?: (string)($body['id'] ?? '');
        $title = trim((string)($body['title'] ?? ''));
        $message = trim((string)($body['body'] ?? ''));
        if ($messageId === '' || $title === '' || $message === '') {
            http_response_code(422);
            echo json_encode(['error' => 'Titlul si mesajul sunt obligatorii.']);
            exit();
        }
        $stmt = $db->prepare(
            'UPDATE whatsapp_predefined_messages
             SET title = ?, body = ?, updated_at = NOW()
             WHERE id = ? AND created_by = ?'
        );
        $stmt->execute([mb_substr($title, 0, 120), $message, $messageId, $ownerUserId]);
        echo json_encode(['success' => true]);

    } elseif ($action === 'deleteWhatsAppPredefinedMessage') {
        $actor = requireAuth($db, $body);
        $targetUserId = trim((string)($body['target_user_id'] ?? ''));
        if ($targetUserId !== '' && ($actor['role'] ?? '') !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Doar administratorul poate sterge mesajele altui utilizator.']);
            exit();
        }
        $ownerUserId = $targetUserId !== '' ? $targetUserId : $actor['id'];
        $messageId = $id ?: (string)($body['id'] ?? '');
        $stmt = $db->prepare('DELETE FROM whatsapp_predefined_messages WHERE id = ? AND created_by = ?');
        $stmt->execute([$messageId, $ownerUserId]);
        echo json_encode(['success' => true]);

    } elseif ($action === 'getClientActivityHistory') {
        requireAdmin($db, $body);
        if (!tableExists($db, 'client_activity_logs')) {
            echo json_encode([]);
            exit();
        }

        $sql = 'SELECT cal.*,
                       u.display_name AS actor_name,
                       u.username AS actor_username,
                       u.role AS actor_role,
                       c.name AS client_name,
                       c.phone AS client_phone,
                       c.email AS client_email,
                       c.status AS client_status,
                       c.qr_code AS client_qr_code
                FROM client_activity_logs cal
                LEFT JOIN app_users u ON u.id = cal.actor_user_id
                LEFT JOIN clients c ON c.id = cal.client_id';
        $params = [];
        if (!empty($_GET['search'])) {
            $search = '%' . $_GET['search'] . '%';
            $sql .= ' WHERE (
                c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ? OR c.qr_code LIKE ?
                OR u.display_name LIKE ? OR u.username LIKE ? OR cal.action LIKE ? OR cal.summary LIKE ?
            )';
            $params = [$search, $search, $search, $search, $search, $search, $search, $search];
        }
        $sql .= ' ORDER BY cal.created_at DESC, cal.id DESC LIMIT 500';
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        echo json_encode(array_map('buildClientActivity', $stmt->fetchAll()));

    } elseif ($action === 'deleteClientActivityHistory') {
        requireAdmin($db, $body);
        if (!tableExists($db, 'client_activity_logs')) {
            echo json_encode(['success' => true, 'deleted_count' => 0]);
            exit();
        }

        $mode = trim((string)($body['mode'] ?? 'range'));
        if ($mode === 'single') {
            $eventId = trim((string)($id ?: ($body['id'] ?? '')));
            if ($eventId === '') {
                http_response_code(422);
                echo json_encode(['error' => 'Modificarea selectata nu este valida.']);
                exit();
            }
            $db->beginTransaction();
            try {
                $stmt = $db->prepare('DELETE FROM client_activity_logs WHERE id = ?');
                $stmt->execute([$eventId]);
                $deletedCount = $stmt->rowCount();
                $verifyStmt = $db->prepare('SELECT COUNT(*) FROM client_activity_logs WHERE id = ?');
                $verifyStmt->execute([$eventId]);
                $databaseDeleted = ((int)$verifyStmt->fetchColumn()) === 0;
                if (!$databaseDeleted) {
                    throw new RuntimeException('Modificarea exista inca in baza de date dupa stergere.');
                }
                $db->commit();
            } catch (Throwable $deleteError) {
                if ($db->inTransaction()) {
                    $db->rollBack();
                }
                throw $deleteError;
            }
            echo json_encode([
                'success' => true,
                'deleted_count' => $deletedCount,
                'database_deleted' => $databaseDeleted,
            ]);
            exit();
        }
        if ($mode === 'all') {
            $deletedCount = (int)$db->exec('DELETE FROM client_activity_logs');
            $remainingCount = (int)$db->query('SELECT COUNT(*) FROM client_activity_logs')->fetchColumn();
            echo json_encode([
                'success' => $remainingCount === 0,
                'deleted_count' => $deletedCount,
                'database_deleted' => $remainingCount === 0,
            ]);
            exit();
        }

        $fromRaw = trim((string)($body['from'] ?? ''));
        $toRaw = trim((string)($body['to'] ?? ''));
        $fromDate = DateTimeImmutable::createFromFormat('!Y-m-d', $fromRaw);
        $toDate = DateTimeImmutable::createFromFormat('!Y-m-d', $toRaw);
        if (!$fromDate || !$toDate || $fromDate->format('Y-m-d') !== $fromRaw || $toDate->format('Y-m-d') !== $toRaw) {
            http_response_code(422);
            echo json_encode(['error' => 'Selecteaza un interval de data valid.']);
            exit();
        }
        if ($fromDate > $toDate) {
            http_response_code(422);
            echo json_encode(['error' => 'Data de inceput trebuie sa fie inaintea datei finale.']);
            exit();
        }

        $stmt = $db->prepare('DELETE FROM client_activity_logs WHERE created_at >= ? AND created_at < ?');
        $stmt->execute([
            $fromDate->format('Y-m-d 00:00:00'),
            $toDate->modify('+1 day')->format('Y-m-d 00:00:00'),
        ]);
        $verifyStmt = $db->prepare('SELECT COUNT(*) FROM client_activity_logs WHERE created_at >= ? AND created_at < ?');
        $verifyStmt->execute([
            $fromDate->format('Y-m-d 00:00:00'),
            $toDate->modify('+1 day')->format('Y-m-d 00:00:00'),
        ]);
        $databaseDeleted = ((int)$verifyStmt->fetchColumn()) === 0;
        echo json_encode([
            'success' => $databaseDeleted,
            'deleted_count' => $stmt->rowCount(),
            'database_deleted' => $databaseDeleted,
        ]);

    } elseif ($action === 'getClients') {
        $authUser = currentUserOrNull($db, $body);
        $sql    = $clientJoin . ' WHERE 1=1';
        $params = [];
        if (isRestrictedMobileUser($authUser)) {
            $sql .= ' AND (c.owner_user_id = ? OR EXISTS (
                SELECT 1 FROM client_user_access cua
                WHERE cua.client_id = c.id AND cua.user_id = ?
            ))';
            $params[] = $authUser['id'];
            $params[] = $authUser['id'];
        }
        if (!empty($_GET['search'])) {
            $s       = '%' . $_GET['search'] . '%';
            $sql    .= ' AND (c.name LIKE ? OR c.phone LIKE ? OR c.qr_code LIKE ?)';
            $params  = array_merge($params, [$s, $s, $s]);
        }
        if (!empty($_GET['profileId'])) {
            $sql    .= ' AND c.profile_id = ?';
            $params[] = $_GET['profileId'];
        }
        $sql .= ' ORDER BY c.created_at DESC';
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        echo json_encode(array_map('buildClient', $stmt->fetchAll()));

    } elseif ($action === 'getClientById') {
        $authUser = currentUserOrNull($db, $body, 'mobile');
        $sql = $clientJoin . ' WHERE c.id = ?';
        $params = [$id];
        if (isRestrictedMobileUser($authUser)) {
            $sql .= ' AND (c.owner_user_id = ? OR EXISTS (
                SELECT 1 FROM client_user_access cua
                WHERE cua.client_id = c.id AND cua.user_id = ?
            ))';
            $params[] = $authUser['id'];
            $params[] = $authUser['id'];
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch();
        echo json_encode($row ? buildClient($row) : null);

    } elseif ($action === 'getClientByQrCode') {
        $stmt = $db->prepare($clientJoin . ' WHERE c.qr_code = ?');
        $stmt->execute([$_GET['qrCode'] ?? '']);
        $row = $stmt->fetch();
        echo json_encode($row ? buildClient($row) : null);

    } elseif ($action === 'createClient') {
        $authUser = currentUserOrNull($db, $body);
        $newId = uuid();
        $collaboratorCosts = is_array($body['collaborator_costs'] ?? null) ? $body['collaborator_costs'] : [];
        $expenseCosts = is_array($body['expense_costs'] ?? null) ? $body['expense_costs'] : [];
        $manoperaTotal = !empty($collaboratorCosts)
            ? collaboratorCostsPayloadTotal($collaboratorCosts)
            : (float)($body['manopera_colaboratori'] ?? 0);
        $otherExpensesTotal = !empty($expenseCosts)
            ? expenseCostsPayloadTotal($expenseCosts)
            : (float)($body['alte_cheltuieli'] ?? 0);
        $stmt  = $db->prepare(
            'INSERT INTO clients
             (id, name, phone, email, status, qr_code, price, discount_percentage, manopera_colaboratori, valoare_piese, alte_cheltuieli, notes, profile_id, owner_user_id)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $newId,
            trim($body['name']  ?? ''),
            trim($body['phone'] ?? ''),
            !empty($body['email'])      ? trim($body['email'])      : null,
            'va_folosi_codul',
            $body['qr_code']            ?? '',
            (float)($body['price']      ?? 0),
            (float)($body['discount_percentage'] ?? 0),
            $manoperaTotal,
            (float)($body['valoare_piese'] ?? 0),
            $otherExpensesTotal,
            !empty($body['notes'])      ? trim($body['notes'])      : null,
            !empty($body['profile_id']) ? $body['profile_id']       : null,
            $authUser['id'] ?? null,
        ]);
        if (is_array($body['collaborator_costs'] ?? null)) {
            $manoperaTotal = saveClientCollaboratorCosts($db, $newId, $collaboratorCosts);
            $totalStmt = $db->prepare('UPDATE clients SET manopera_colaboratori = ? WHERE id = ?');
            $totalStmt->execute([$manoperaTotal, $newId]);
        }
        if (is_array($body['expense_costs'] ?? null)) {
            $otherExpensesTotal = saveClientExpenseCosts($db, $newId, $expenseCosts);
            $db->prepare('UPDATE clients SET alte_cheltuieli = ? WHERE id = ?')
                ->execute([$otherExpensesTotal, $newId]);
        }
        grantClientAccess($db, $newId, $authUser['id'] ?? null, 'owner');
        logClientActivity($db, $newId, $authUser, 'created', 'Client adaugat', [
            'name' => trim($body['name'] ?? ''),
            'phone' => trim($body['phone'] ?? ''),
            'qr_code' => $body['qr_code'] ?? '',
            'price' => (float)($body['price'] ?? 0),
            'discount_percentage' => (float)($body['discount_percentage'] ?? 0),
        ]);
        $stmt2 = $db->prepare($clientJoin . ' WHERE c.id = ?');
        $stmt2->execute([$newId]);
        echo json_encode(buildClient($stmt2->fetch()));

    } elseif ($action === 'updateClient') {
        $authUser = requireAuth($db, $body);
        // Verifica statusul curent.
        $checkStmt = $db->prepare('SELECT * FROM clients WHERE id = ?');
        $checkStmt->execute([$id]);
        $current = $checkStmt->fetch();
        if (!$current) {
            http_response_code(404);
            echo json_encode(['error' => 'Client inexistent']);
            exit();
        }
        $role = $authUser['role'] ?? '';
        if (!userHasClientAccess($db, $authUser, $current)) {
            http_response_code(403);
            echo json_encode(['error' => 'Nu ai acces la acest client.']);
            exit();
        }
        if ($role === 'user' && !userCanEditClients($authUser)) {
            http_response_code(403);
            echo json_encode(['error' => 'Editarea clientilor nu este permisa pentru acest cont. Activeaza accesul din User Login System.']);
            exit();
        }
        if ($role !== 'admin' && !empty($current['is_finalized'])) {
            http_response_code(423);
            echo json_encode(['error' => 'Clientul este finalizat si nu mai poate fi editat.']);
            exit();
        }
        $currentStatus = $current['status'];
        $newStatus = $role === 'admin'
            ? ($body['status'] ?? $currentStatus)
            : (($currentStatus === 'cod_folosit') ? 'cod_folosit' : ($body['status'] ?? 'interesat'));
        if (!in_array($newStatus, ['interesat', 'va_folosi_codul', 'cod_folosit'], true)) {
            $newStatus = $currentStatus;
        }
        $newIsFinalized = $role === 'admin' && array_key_exists('is_finalized', $body)
            ? (int)!empty($body['is_finalized'])
            : (int)!empty($current['is_finalized']);
        $newQrUsed = $role === 'admin' && array_key_exists('qr_used', $body)
            ? (int)!empty($body['qr_used'])
            : (int)!empty($current['qr_used']);
        $newQrUsedAt = $newQrUsed
            ? (($current['qr_used_at'] ?? null) ?: date('Y-m-d H:i:s'))
            : null;

        // Calculeaza noile valori pret/reducere
        $newPrice    = (float)($body['price']               ?? 0);
        $newDiscount = (float)($body['discount_percentage'] ?? 0);

        $newProfileId = !empty($body['profile_id']) ? $body['profile_id'] : null;
        if ($currentStatus === 'cod_folosit' && $role === 'user') {
            // Dupa folosirea QR-ului, numele ramane blocat pentru user.
            // Managerul il poate corecta pana la finalizare.
            $newName      = trim($current['name']       ?? '');
        } else {
            $newName      = trim($body['name']       ?? '');
        }

        $collaboratorCosts = is_array($body['collaborator_costs'] ?? null) ? $body['collaborator_costs'] : [];
        $expenseCosts = is_array($body['expense_costs'] ?? null) ? $body['expense_costs'] : [];
        $manoperaTotal = !empty($collaboratorCosts)
            ? collaboratorCostsPayloadTotal($collaboratorCosts)
            : (float)($body['manopera_colaboratori'] ?? 0);
        $otherExpensesTotal = !empty($expenseCosts)
            ? expenseCostsPayloadTotal($expenseCosts)
            : (float)($body['alte_cheltuieli'] ?? 0);
        $afterForLog = [
            'name' => $newName,
            'phone' => trim($body['phone'] ?? ''),
            'email' => !empty($body['email']) ? trim($body['email']) : null,
            'status' => $newStatus,
            'price' => $newPrice,
            'discount_percentage' => $newDiscount,
            'manopera_colaboratori' => $manoperaTotal,
            'valoare_piese' => (float)($body['valoare_piese'] ?? 0),
            'alte_cheltuieli' => $otherExpensesTotal,
            'notes' => !empty($body['notes']) ? trim($body['notes']) : null,
            'profile_id' => $newProfileId,
            'is_finalized' => $newIsFinalized,
            'qr_used' => $newQrUsed,
        ];
        $changes = clientFieldChanges($current, $afterForLog);

        $stmt = $db->prepare(
            "UPDATE clients
             SET name=?, phone=?, email=?, status=?, qr_used=?, qr_used_at=?, is_finalized=?,
                 price=?, discount_percentage=?, manopera_colaboratori=?, valoare_piese=?, alte_cheltuieli=?, notes=?, profile_id=?
             WHERE id=?"
        );
        $stmt->execute([
            $newName,
            trim($body['phone'] ?? ''),
            !empty($body['email']) ? trim($body['email']) : null,
            $newStatus,
            $newQrUsed,
            $newQrUsedAt,
            $newIsFinalized,
            $newPrice,
            $newDiscount,
            $manoperaTotal,
            (float)($body['valoare_piese'] ?? 0),
            $otherExpensesTotal,
            !empty($body['notes']) ? trim($body['notes']) : null,
            $newProfileId,
            $id,
        ]);
        if (is_array($body['collaborator_costs'] ?? null)) {
            $manoperaTotal = saveClientCollaboratorCosts($db, $id, $collaboratorCosts);
            $totalStmt = $db->prepare('UPDATE clients SET manopera_colaboratori = ? WHERE id = ?');
            $totalStmt->execute([$manoperaTotal, $id]);
        }
        if (is_array($body['expense_costs'] ?? null)) {
            $otherExpensesTotal = saveClientExpenseCosts($db, $id, $expenseCosts);
            $db->prepare('UPDATE clients SET alte_cheltuieli = ? WHERE id = ?')
                ->execute([$otherExpensesTotal, $id]);
        }
        logClientActivity($db, $id, $authUser, 'updated', 'Client editat', [
            'changes' => $changes,
        ]);
        $stmt2 = $db->prepare($clientJoin . ' WHERE c.id = ?');
        $stmt2->execute([$id]);
        echo json_encode(buildClient($stmt2->fetch()));

    } elseif ($action === 'finalizeClient') {
        $authUser = requireAuth($db, $body);
        if (!userCanFinalizeClients($authUser)) {
            http_response_code(403);
            echo json_encode(['error' => 'Contul de tip user nu are dreptul sa finalizeze clienti.']);
            exit();
        }
        $checkStmt = $db->prepare('SELECT * FROM clients WHERE id = ?');
        $checkStmt->execute([$id]);
        $current = $checkStmt->fetch();
        if (!$current) {
            http_response_code(404);
            echo json_encode(['error' => 'Client inexistent']);
            exit();
        }
        if (!userHasClientAccess($db, $authUser, $current)) {
            http_response_code(403);
            echo json_encode(['error' => 'Nu ai acces sa finalizezi acest client.']);
            exit();
        }

        if (!empty($current['is_finalized'])) {
            $stmt2 = $db->prepare($clientJoin . ' WHERE c.id = ?');
            $stmt2->execute([$id]);
            echo json_encode(buildClient($stmt2->fetch()));
            exit();
        }

        $canEditClient = userCanEditClients($authUser);
        $collaboratorCosts = $canEditClient && is_array($body['collaborator_costs'] ?? null) ? $body['collaborator_costs'] : [];
        $expenseCosts = $canEditClient && is_array($body['expense_costs'] ?? null) ? $body['expense_costs'] : [];
        $manoperaTotal = !empty($collaboratorCosts)
            ? collaboratorCostsPayloadTotal($collaboratorCosts)
            : (float)($canEditClient ? ($body['manopera_colaboratori'] ?? ($current['manopera_colaboratori'] ?? 0)) : ($current['manopera_colaboratori'] ?? 0));
        $otherExpensesTotal = !empty($expenseCosts)
            ? expenseCostsPayloadTotal($expenseCosts)
            : (float)($canEditClient ? ($body['alte_cheltuieli'] ?? ($current['alte_cheltuieli'] ?? 0)) : ($current['alte_cheltuieli'] ?? 0));
        $finalPrice = (float)($canEditClient ? ($body['price'] ?? $current['price']) : $current['price']);
        $finalDiscount = (float)($canEditClient ? ($body['discount_percentage'] ?? $current['discount_percentage']) : $current['discount_percentage']);

        if ($finalPrice < 0) {
            http_response_code(422);
            echo json_encode(['error' => 'Pretul lucrarii trebuie sa fie o valoare pozitiva sau 0.']);
            exit();
        }

        $stmt = $db->prepare(
            'UPDATE clients
             SET name=?, phone=?, email=?, status="cod_folosit",
                 qr_used=1, qr_used_at=COALESCE(qr_used_at, NOW()),
                 price=?, discount_percentage=?, manopera_colaboratori=?, valoare_piese=?, alte_cheltuieli=?,
                 notes=?, profile_id=?, is_finalized=1
             WHERE id=?'
        );
        $stmt->execute([
            $canEditClient ? trim($body['name'] ?? $current['name']) : $current['name'],
            $canEditClient ? trim($body['phone'] ?? $current['phone']) : $current['phone'],
            $canEditClient ? (!empty($body['email']) ? trim($body['email']) : null) : $current['email'],
            $finalPrice,
            $finalDiscount,
            $manoperaTotal,
            (float)($canEditClient ? ($body['valoare_piese'] ?? ($current['valoare_piese'] ?? 0)) : ($current['valoare_piese'] ?? 0)),
            $otherExpensesTotal,
            $canEditClient ? (!empty($body['notes']) ? trim($body['notes']) : null) : $current['notes'],
            $canEditClient ? (!empty($body['profile_id']) ? $body['profile_id'] : null) : $current['profile_id'],
            $id,
        ]);
        if ($canEditClient && is_array($body['collaborator_costs'] ?? null)) {
            $manoperaTotal = saveClientCollaboratorCosts($db, $id, $collaboratorCosts);
            $totalStmt = $db->prepare('UPDATE clients SET manopera_colaboratori = ? WHERE id = ?');
            $totalStmt->execute([$manoperaTotal, $id]);
        }
        if ($canEditClient && is_array($body['expense_costs'] ?? null)) {
            $otherExpensesTotal = saveClientExpenseCosts($db, $id, $expenseCosts);
            $db->prepare('UPDATE clients SET alte_cheltuieli = ? WHERE id = ?')
                ->execute([$otherExpensesTotal, $id]);
        }
        logClientActivity($db, $id, $authUser, 'finalized', 'Client finalizat', [
            'price' => $finalPrice,
            'discount_percentage' => $finalDiscount,
            'manopera_colaboratori' => $manoperaTotal,
            'valoare_piese' => (float)($canEditClient ? ($body['valoare_piese'] ?? ($current['valoare_piese'] ?? 0)) : ($current['valoare_piese'] ?? 0)),
            'alte_cheltuieli' => $otherExpensesTotal,
        ]);
        $stmt2 = $db->prepare($clientJoin . ' WHERE c.id = ?');
        $stmt2->execute([$id]);
        echo json_encode(buildClient($stmt2->fetch()));

    } elseif ($action === 'deleteClient') {
        $authUser = requireAuth($db, $body);
        $checkStmt = $db->prepare('SELECT * FROM clients WHERE id = ?');
        $checkStmt->execute([$id]);
        $current = $checkStmt->fetch();
        if (!$current) {
            http_response_code(404);
            echo json_encode(['error' => 'Client inexistent']);
            exit();
        }
        $role = $authUser['role'] ?? '';
        $canDeleteClient = $role === 'admin' || ($role === 'manager' && empty($current['is_finalized']));
        if (!$canDeleteClient) {
            http_response_code(403);
            echo json_encode(['error' => 'Doar adminul poate sterge orice client. Managerul poate sterge doar clienti nefinalizati.']);
            exit();
        }
        $stmt = $db->prepare('DELETE FROM clients WHERE id = ?');
        $stmt->execute([$id]);
        echo json_encode(['success' => true]);

    } elseif ($action === 'markQrUsed') {
        $authUser = currentUserOrNull($db, $body, 'mobile');
        $stmt = $db->prepare(
            'UPDATE clients
             SET qr_used=1, qr_used_at=NOW(), status="cod_folosit",
                 price=?, discount_percentage=?, notes=?
             WHERE id=?'
        );
        $stmt->execute([
            (float)($body['price']               ?? 0),
            (float)($body['discount_percentage'] ?? 0),
            !empty($body['notes']) ? trim($body['notes']) : null,
            $id,
        ]);
        grantClientAccess($db, $id, $authUser['id'] ?? null, 'scan');
        logClientActivity($db, $id, $authUser, 'scanned', 'Cod QR scanat si utilizat', [
            'price' => (float)($body['price'] ?? 0),
            'discount_percentage' => (float)($body['discount_percentage'] ?? 0),
            'notes' => !empty($body['notes']) ? trim($body['notes']) : null,
        ]);
        $stmt2 = $db->prepare($clientJoin . ' WHERE c.id = ?');
        $stmt2->execute([$id]);
        echo json_encode(buildClient($stmt2->fetch()));

    // ── Profiles ─────────────────────────────────────────────────────────────

    } elseif ($action === 'getProfiles') {
        $stmt = $db->query('SELECT * FROM profiles ORDER BY created_at ASC');
        echo json_encode($stmt->fetchAll());

    } elseif ($action === 'createProfile') {
        requireAuth($db, $body, null, ['admin', 'manager']);
        $newId = uuid();
        $stmt  = $db->prepare(
            'INSERT INTO profiles (id, name, role, phone, email, percentage, color) VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $newId,
            trim($body['name']    ?? ''),
            trim($body['role']    ?? 'agent'),
            !empty(trim((string)($body['phone'] ?? ''))) ? trim($body['phone']) : null,
            !empty(trim((string)($body['email'] ?? ''))) ? trim($body['email']) : null,
            (float)($body['percentage'] ?? 0),
            trim($body['color']   ?? '#FF6B35'),
        ]);
        $stmt2 = $db->prepare('SELECT * FROM profiles WHERE id = ?');
        $stmt2->execute([$newId]);
        echo json_encode($stmt2->fetch());

    } elseif ($action === 'updateProfile') {
        requireAuth($db, $body, null, ['admin', 'manager']);
        $stmt = $db->prepare(
            'UPDATE profiles SET name=?, role=?, phone=?, email=?, percentage=?, color=? WHERE id=?'
        );
        $stmt->execute([
            trim($body['name']    ?? ''),
            trim($body['role']    ?? 'agent'),
            !empty(trim((string)($body['phone'] ?? ''))) ? trim($body['phone']) : null,
            !empty(trim((string)($body['email'] ?? ''))) ? trim($body['email']) : null,
            (float)($body['percentage'] ?? 0),
            trim($body['color']   ?? '#FF6B35'),
            $id,
        ]);
        $stmt2 = $db->prepare('SELECT * FROM profiles WHERE id = ?');
        $stmt2->execute([$id]);
        echo json_encode($stmt2->fetch());

    } elseif ($action === 'deleteProfile') {
        requireAuth($db, $body, null, ['admin', 'manager']);
        $stmt = $db->prepare('DELETE FROM profiles WHERE id = ?');
        $stmt->execute([$id]);
        echo json_encode(['success' => true]);

    // Collaborators

    } elseif ($action === 'getCollaborators') {
        if (!tableExists($db, 'collaborators')) {
            echo json_encode([]);
            exit();
        }
        $stmt = $db->query('SELECT * FROM collaborators ORDER BY created_at ASC');
        echo json_encode(array_map('buildCollaborator', $stmt->fetchAll()));

    } elseif ($action === 'createCollaborator') {
        requireAuth($db, $body, null, ['admin', 'manager']);
        $newId = uuid();
        $stmt  = $db->prepare(
            'INSERT INTO collaborators (id, name, role, phone, email, color) VALUES (?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $newId,
            trim($body['name']  ?? ''),
            trim($body['role']  ?? ''),
            !empty(trim((string)($body['phone'] ?? ''))) ? trim($body['phone']) : null,
            !empty(trim((string)($body['email'] ?? ''))) ? trim($body['email']) : null,
            trim($body['color'] ?? '#14B8A6'),
        ]);
        $stmt2 = $db->prepare('SELECT * FROM collaborators WHERE id = ?');
        $stmt2->execute([$newId]);
        echo json_encode(buildCollaborator($stmt2->fetch()));

    } elseif ($action === 'updateCollaborator') {
        requireAuth($db, $body, null, ['admin', 'manager']);
        $stmt = $db->prepare(
            'UPDATE collaborators SET name=?, role=?, phone=?, email=?, color=? WHERE id=?'
        );
        $stmt->execute([
            trim($body['name']  ?? ''),
            trim($body['role']  ?? ''),
            !empty(trim((string)($body['phone'] ?? ''))) ? trim($body['phone']) : null,
            !empty(trim((string)($body['email'] ?? ''))) ? trim($body['email']) : null,
            trim($body['color'] ?? '#14B8A6'),
            $id,
        ]);
        $stmt2 = $db->prepare('SELECT * FROM collaborators WHERE id = ?');
        $stmt2->execute([$id]);
        echo json_encode(buildCollaborator($stmt2->fetch()));

    } elseif ($action === 'deleteCollaborator') {
        requireAuth($db, $body, null, ['admin', 'manager']);
        $stmt = $db->prepare('DELETE FROM collaborators WHERE id = ?');
        $stmt->execute([$id]);
        echo json_encode(['success' => true]);

    // Expense categories

    } elseif ($action === 'getExpenseCategories') {
        $stmt = $db->query('SELECT * FROM expense_categories ORDER BY name ASC');
        echo json_encode(array_map('buildExpenseCategory', $stmt->fetchAll()));

    } elseif ($action === 'createExpenseCategory') {
        requireAuth($db, $body, null, ['admin', 'manager']);
        $name = trim($body['name'] ?? '');
        if ($name === '') {
            http_response_code(422);
            echo json_encode(['error' => 'Denumirea cheltuielii este obligatorie.']);
            exit();
        }
        $newId = uuid();
        $db->prepare('INSERT INTO expense_categories (id, name, color) VALUES (?, ?, ?)')
            ->execute([$newId, $name, trim($body['color'] ?? '#EF4444')]);
        $stmt = $db->prepare('SELECT * FROM expense_categories WHERE id = ?');
        $stmt->execute([$newId]);
        echo json_encode(buildExpenseCategory($stmt->fetch()));

    } elseif ($action === 'updateExpenseCategory') {
        requireAuth($db, $body, null, ['admin', 'manager']);
        $name = trim($body['name'] ?? '');
        if ($name === '') {
            http_response_code(422);
            echo json_encode(['error' => 'Denumirea cheltuielii este obligatorie.']);
            exit();
        }
        $db->prepare('UPDATE expense_categories SET name=?, color=? WHERE id=?')
            ->execute([$name, trim($body['color'] ?? '#EF4444'), $id]);
        $stmt = $db->prepare('SELECT * FROM expense_categories WHERE id = ?');
        $stmt->execute([$id]);
        echo json_encode(buildExpenseCategory($stmt->fetch()));

    } elseif ($action === 'deleteExpenseCategory') {
        requireAuth($db, $body, null, ['admin', 'manager']);
        $db->prepare('DELETE FROM expense_categories WHERE id = ?')->execute([$id]);
        echo json_encode(['success' => true]);

    // ── Service Sheets ────────────────────────────────────────────────────────

    } elseif ($action === 'createServiceSheet') {
        $newId = uuid();
        $stmt  = $db->prepare(
            'INSERT INTO service_sheets
             (id, qr_code, client_name, client_phone, client_email,
              client_package_price, client_discount, service_date,
              mechanic_name, service_type, work_description,
              parts_used, observations, final_price)
             VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $newId,
            trim($body['qr_code']              ?? ''),
            trim($body['client_name']          ?? ''),
            trim($body['client_phone']         ?? ''),
            !empty($body['client_email'])      ? trim($body['client_email']) : null,
            (float)($body['client_package_price'] ?? 0),
            (float)($body['client_discount']   ?? 0),
            trim($body['mechanic_name']        ?? ''),
            trim($body['service_type']         ?? 'Verificare generala'),
            trim($body['work_description']     ?? ''),
            !empty($body['parts_used'])        ? trim($body['parts_used'])   : null,
            !empty($body['observations'])      ? trim($body['observations']) : null,
            (float)($body['final_price']       ?? 0),
        ]);
        $stmt2 = $db->prepare('SELECT * FROM service_sheets WHERE id = ?');
        $stmt2->execute([$newId]);
        $row = $stmt2->fetch();
        $row['client_package_price'] = (float)$row['client_package_price'];
        $row['client_discount']      = (float)$row['client_discount'];
        $row['final_price']          = (float)$row['final_price'];
        echo json_encode($row);

    } elseif ($action === 'getServiceSheets') {
        $sql    = 'SELECT * FROM service_sheets WHERE 1=1';
        $params = [];
        if (!empty($_GET['search'])) {
            $s       = '%' . $_GET['search'] . '%';
            $sql    .= ' AND (client_name LIKE ? OR client_phone LIKE ? OR qr_code LIKE ? OR mechanic_name LIKE ?)';
            $params  = [$s, $s, $s, $s];
        }
        $sql .= ' ORDER BY created_at DESC';
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        foreach ($rows as &$r) {
            $r['client_package_price'] = (float)$r['client_package_price'];
            $r['client_discount']      = (float)$r['client_discount'];
            $r['final_price']          = (float)$r['final_price'];
        }
        echo json_encode($rows);

    // ── Stats ─────────────────────────────────────────────────────────────────

    } elseif ($action === 'getStats') {
        // Period filter: mobile legacy aliases + desktop analytical ranges.
        $period = $_GET['period'] ?? 'all';
        $today = new DateTimeImmutable('today');
        $tomorrow = $today->modify('+1 day');
        $fromDate = null;
        $toDate = null;

        switch ($period) {
            case 'today':
                $fromDate = $today;
                $toDate = $tomorrow;
                break;
            case 'week':
            case '7d':
                $fromDate = $today->modify('-6 days');
                $toDate = $tomorrow;
                break;
            case 'month':
                $fromDate = $today->modify('first day of this month');
                $toDate = $tomorrow;
                break;
            case '30d':
                $fromDate = $today->modify('-29 days');
                $toDate = $tomorrow;
                break;
            case '90d':
                $fromDate = $today->modify('-89 days');
                $toDate = $tomorrow;
                break;
            case 'year':
                $fromDate = new DateTimeImmutable(date('Y-01-01'));
                $toDate = $tomorrow;
                break;
            case 'custom':
                $fromRaw = $_GET['from'] ?? '';
                $toRaw = $_GET['to'] ?? '';
                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fromRaw) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $toRaw)) {
                    throw new RuntimeException('Intervalul personalizat nu este valid.');
                }
                $fromDate = new DateTimeImmutable($fromRaw);
                $toDate = (new DateTimeImmutable($toRaw))->modify('+1 day');
                if ($fromDate >= $toDate) {
                    throw new RuntimeException('Data de inceput trebuie sa fie inaintea datei finale.');
                }
                break;
            default:
                $period = 'all';
        }

        $rangeCondition = static function (string $column, ?DateTimeImmutable $from, ?DateTimeImmutable $to) use ($db): string {
            if (!$from || !$to) {
                return '1=1';
            }
            return sprintf(
                '%s >= %s AND %s < %s',
                $column,
                $db->quote($from->format('Y-m-d H:i:s')),
                $column,
                $db->quote($to->format('Y-m-d H:i:s'))
            );
        };
        $scalar = static function (PDO $db, string $sql): float {
            return (float)$db->query($sql)->fetchColumn();
        };

        $usedCondition = $rangeCondition('qr_used_at', $fromDate, $toDate);
        $createdCondition = $rangeCondition('created_at', $fromDate, $toDate);
        $dateWhere = $period === 'all' ? '' : " AND {$usedCondition}";
        $createdDateWhere = $period === 'all' ? '' : " AND {$createdCondition}";
        $dateWhereClient = str_replace('qr_used_at', 'c.qr_used_at', $dateWhere);

        $totalClients = (int)$scalar($db, "SELECT COUNT(*) FROM clients WHERE {$createdCondition}");

        $revQuery     = "SELECT COALESCE(SUM(price * (1 - discount_percentage/100)),0) FROM clients WHERE status='cod_folosit'{$dateWhere}";
        $totalRevenue = $scalar($db, $revQuery);
        $expensesQuery = "SELECT COALESCE(SUM(manopera_colaboratori + valoare_piese + alte_cheltuieli),0) FROM clients WHERE status='cod_folosit'{$dateWhere}";
        $totalExpenses = $scalar($db, $expensesQuery);
        $onHoldWhere = "is_finalized = 0 {$createdDateWhere}";
        $onHoldClients = (int)$scalar($db, "SELECT COUNT(*) FROM clients WHERE {$onHoldWhere}");
        $onHoldQuery = "SELECT COALESCE(SUM(price * (1 - discount_percentage/100)),0)
                        FROM clients
                        WHERE {$onHoldWhere}";
        $onHoldRevenue = $scalar($db, $onHoldQuery);
        $qrWhere = "COALESCE(qr_code, '') <> '' AND {$createdCondition}";
        $qrTotal = (int)$scalar($db, "SELECT COUNT(*) FROM clients WHERE {$qrWhere}");
        $qrUsed = (int)$scalar($db, "SELECT COUNT(*) FROM clients WHERE {$qrWhere} AND qr_used = 1");
        $qrGenerated = max($qrTotal - $qrUsed, 0);
        $qrPendingRevenue = $scalar(
            $db,
            "SELECT COALESCE(SUM(price * (1 - discount_percentage/100)),0)
             FROM clients
             WHERE {$qrWhere} AND (qr_used = 0 OR qr_used IS NULL)"
        );

        $statusRows   = $db->query("SELECT status, COUNT(*) AS cnt FROM clients WHERE {$createdCondition} GROUP BY status")->fetchAll();
        $statusCounts = ['interesat' => 0, 'va_folosi_codul' => 0, 'cod_folosit' => 0];
        foreach ($statusRows as $sr) {
            $statusCounts[$sr['status']] = (int)$sr['cnt'];
        }

        $profiles    = $db->query('SELECT * FROM profiles')->fetchAll();
        $profileStats = [];
        foreach ($profiles as $profile) {
            $pid = $profile['id'];

            $cntStmt = $db->prepare("SELECT COUNT(*) FROM clients WHERE profile_id = ?{$createdDateWhere}");
            $cntStmt->execute([$pid]);
            $clientCount = (int)$cntStmt->fetchColumn();

            $revStmt = $db->prepare("SELECT COALESCE(SUM(price * (1 - discount_percentage/100)),0) FROM clients WHERE profile_id = ? AND status='cod_folosit'{$dateWhere}");
            $revStmt->execute([$pid]);
            $rev = (float)$revStmt->fetchColumn();

            $expenseStmt = $db->prepare("SELECT COALESCE(SUM(manopera_colaboratori + valoare_piese + alte_cheltuieli),0) FROM clients WHERE profile_id = ? AND status='cod_folosit'{$dateWhere}");
            $expenseStmt->execute([$pid]);
            $expenses = (float)$expenseStmt->fetchColumn();

            $pct             = (float)$profile['percentage'] / 100;
            $profileEarnings = $rev * $pct;
            $gtrotsEarnings  = $rev - $profileEarnings - $expenses;

            $profileStats[] = [
                'profile'         => $profile,
                'clientCount'     => $clientCount,
                'totalRevenue'    => $rev,
                'profileEarnings' => $profileEarnings,
                'gtrotsEarnings'  => $gtrotsEarnings,
            ];
        }

        $collaboratorStats = [];
        if (tableExists($db, 'client_collaborator_costs') && tableExists($db, 'collaborators')) {
            $collaboratorRows = $db->query(
                "SELECT
                    COALESCE(cc.collaborator_id, CONCAT('deleted-', MD5(cc.collaborator_name))) AS collaborator_key,
                    COALESCE(cc.collaborator_id, '') AS collaborator_id,
                    COALESCE(co.name, cc.collaborator_name) AS name,
                    COALESCE(co.role, '') AS role,
                    COALESCE(co.color, cc.collaborator_color) AS color,
                    MIN(cc.created_at) AS created_at,
                    COUNT(DISTINCT c.id) AS client_count,
                    COALESCE(SUM(cc.cost), 0) AS total_cost
                 FROM client_collaborator_costs cc
                 JOIN clients c ON c.id = cc.client_id
                 LEFT JOIN collaborators co ON cc.collaborator_id = co.id
                 WHERE c.status='cod_folosit'{$dateWhereClient}
                 GROUP BY collaborator_key, collaborator_id, name, role, color
                 ORDER BY total_cost DESC"
            )->fetchAll();

            foreach ($collaboratorRows as $row) {
                if (!empty($row['collaborator_id'])) {
                    $dailyWhere = 'cc.collaborator_id = ?';
                    $dailyParams = [$row['collaborator_id']];
                } else {
                    $dailyWhere = 'cc.collaborator_id IS NULL AND cc.collaborator_name = ?';
                    $dailyParams = [$row['name']];
                }

                $dailyStmt = $db->prepare(
                    "SELECT DATE(c.qr_used_at) AS day,
                            COUNT(DISTINCT c.id) AS client_count,
                            COALESCE(SUM(cc.cost), 0) AS total_cost
                     FROM client_collaborator_costs cc
                     JOIN clients c ON c.id = cc.client_id
                     WHERE {$dailyWhere}
                       AND c.status='cod_folosit'{$dateWhereClient}
                     GROUP BY DATE(c.qr_used_at)
                     ORDER BY day DESC"
                );
                $dailyStmt->execute($dailyParams);
                $dailyRows = [];
                foreach ($dailyStmt->fetchAll() as $daily) {
                    if (empty($daily['day'])) {
                        continue;
                    }
                    $dailyRows[] = [
                        'date'        => $daily['day'],
                        'clientCount' => (int)$daily['client_count'],
                        'totalCost'   => (float)$daily['total_cost'],
                    ];
                }

                $collaboratorStats[] = [
                    'collaborator' => [
                        'id'         => !empty($row['collaborator_id']) ? $row['collaborator_id'] : $row['collaborator_key'],
                        'name'       => $row['name'],
                        'role'       => $row['role'],
                        'color'      => $row['color'] ?: '#14B8A6',
                        'created_at' => $row['created_at'] ?? '',
                    ],
                    'clientCount' => (int)$row['client_count'],
                    'totalCost'   => (float)$row['total_cost'],
                    'daily'       => $dailyRows,
                ];
            }
        }

        $totalProfileEarnings = 0.0;
        foreach ($profileStats as $profileStat) {
            $totalProfileEarnings += (float)$profileStat['profileEarnings'];
        }
        $netProfit = $totalRevenue - $totalExpenses - $totalProfileEarnings;

        $previous = null;
        if ($fromDate && $toDate) {
            $rangeSeconds = $toDate->getTimestamp() - $fromDate->getTimestamp();
            $previousTo = $fromDate;
            $previousFrom = $fromDate->modify("-{$rangeSeconds} seconds");
            $previousUsedCondition = $rangeCondition('c.qr_used_at', $previousFrom, $previousTo);
            $previousCreatedCondition = $rangeCondition('c.created_at', $previousFrom, $previousTo);

            $previousClients = $scalar($db, "SELECT COUNT(*) FROM clients c WHERE {$previousCreatedCondition}");
            $previousRevenue = $scalar(
                $db,
                "SELECT COALESCE(SUM(c.price * (1 - c.discount_percentage/100)),0)
                 FROM clients c
                 WHERE c.status='cod_folosit' AND {$previousUsedCondition}"
            );
            $previousExpenses = $scalar(
                $db,
                "SELECT COALESCE(SUM(c.manopera_colaboratori + c.valoare_piese + c.alte_cheltuieli),0)
                 FROM clients c
                 WHERE c.status='cod_folosit' AND {$previousUsedCondition}"
            );
            $previousProfileEarnings = $scalar(
                $db,
                "SELECT COALESCE(SUM(c.price * (1 - c.discount_percentage/100) * (p.percentage / 100)),0)
                 FROM clients c
                 JOIN profiles p ON p.id = c.profile_id
                 WHERE c.status='cod_folosit' AND {$previousUsedCondition}"
            );
            $previousOnHold = $scalar(
                $db,
                "SELECT COALESCE(SUM(c.price * (1 - c.discount_percentage/100)),0)
                 FROM clients c
                 WHERE c.is_finalized = 0
                   AND {$previousCreatedCondition}"
            );
            $previous = [
                'totalClients'  => (int)$previousClients,
                'totalRevenue'  => $previousRevenue,
                'onHoldRevenue' => $previousOnHold,
                'totalExpenses' => $previousExpenses + $previousProfileEarnings,
                'netProfit'     => $previousRevenue - $previousExpenses - $previousProfileEarnings,
            ];
        }

        $seriesFrom = $fromDate;
        $seriesTo = $toDate;
        if (!$seriesFrom || !$seriesTo) {
            $firstActivity = $db->query(
                "SELECT MIN(activity_date) FROM (
                    SELECT MIN(created_at) AS activity_date FROM clients
                    UNION ALL
                    SELECT MIN(qr_used_at) AS activity_date FROM clients WHERE qr_used_at IS NOT NULL
                 ) activity"
            )->fetchColumn();
            $seriesFrom = $firstActivity ? new DateTimeImmutable((string)$firstActivity) : $today;
            $seriesTo = $tomorrow;
        }

        $seriesDays = max(1, (int)ceil(($seriesTo->getTimestamp() - $seriesFrom->getTimestamp()) / 86400));
        $seriesGranularity = $seriesDays > 120 ? 'month' : 'day';
        $bucketFormat = $seriesGranularity === 'month' ? '%Y-%m' : '%Y-%m-%d';
        $seriesMap = [];
        $cursor = $seriesGranularity === 'month'
            ? $seriesFrom->modify('first day of this month')
            : $seriesFrom->setTime(0, 0);
        while ($cursor < $seriesTo) {
            $key = $cursor->format($seriesGranularity === 'month' ? 'Y-m' : 'Y-m-d');
            $seriesMap[$key] = [
                'key' => $key,
                'label' => $cursor->format($seriesGranularity === 'month' ? 'm.Y' : 'd.m'),
                'revenue' => 0.0,
                'expenses' => 0.0,
                'onHoldRevenue' => 0.0,
                'netProfit' => 0.0,
                'usedClients' => 0,
                'generatedClients' => 0,
            ];
            $cursor = $seriesGranularity === 'month' ? $cursor->modify('+1 month') : $cursor->modify('+1 day');
        }

        $usedSeriesRows = $db->query(
            "SELECT DATE_FORMAT(qr_used_at, '{$bucketFormat}') AS bucket,
                    COUNT(*) AS used_clients,
                    COALESCE(SUM(price * (1 - discount_percentage/100)),0) AS revenue
             FROM clients
             WHERE status='cod_folosit'{$dateWhere}
             GROUP BY bucket
             ORDER BY bucket"
        )->fetchAll();
        foreach ($usedSeriesRows as $row) {
            $key = (string)$row['bucket'];
            if (!isset($seriesMap[$key])) {
                continue;
            }
            $seriesMap[$key]['revenue'] = (float)$row['revenue'];
            $seriesMap[$key]['usedClients'] = (int)$row['used_clients'];
        }

        $financeSeriesRows = $db->query(
            "SELECT DATE_FORMAT(c.qr_used_at, '{$bucketFormat}') AS bucket,
                    COALESCE(SUM(c.manopera_colaboratori + c.valoare_piese + c.alte_cheltuieli
                      + CASE WHEN p.id IS NOT NULL
                        THEN c.price * (1 - c.discount_percentage/100) * (p.percentage / 100)
                        ELSE 0 END),0) AS expenses
             FROM clients c
             LEFT JOIN profiles p ON p.id = c.profile_id
             WHERE c.status='cod_folosit'{$dateWhereClient}
             GROUP BY bucket
             ORDER BY bucket"
        )->fetchAll();
        foreach ($financeSeriesRows as $row) {
            $key = (string)$row['bucket'];
            if (!isset($seriesMap[$key])) {
                continue;
            }
            $seriesMap[$key]['expenses'] = (float)$row['expenses'];
            $seriesMap[$key]['netProfit'] = $seriesMap[$key]['revenue'] - $seriesMap[$key]['expenses'];
        }

        $generatedSeriesRows = $db->query(
            "SELECT DATE_FORMAT(created_at, '{$bucketFormat}') AS bucket, COUNT(*) AS generated_clients
             FROM clients
             WHERE {$createdCondition}
             GROUP BY bucket
             ORDER BY bucket"
        )->fetchAll();
        foreach ($generatedSeriesRows as $row) {
            $key = (string)$row['bucket'];
            if (isset($seriesMap[$key])) {
                $seriesMap[$key]['generatedClients'] = (int)$row['generated_clients'];
            }
        }

        $onHoldSeriesRows = $db->query(
            "SELECT DATE_FORMAT(created_at, '{$bucketFormat}') AS bucket,
                    COALESCE(SUM(price * (1 - discount_percentage/100)),0) AS on_hold_revenue
             FROM clients
             WHERE is_finalized = 0 AND {$createdCondition}
             GROUP BY bucket
             ORDER BY bucket"
        )->fetchAll();
        foreach ($onHoldSeriesRows as $row) {
            $key = (string)$row['bucket'];
            if (isset($seriesMap[$key])) {
                $seriesMap[$key]['onHoldRevenue'] = (float)$row['on_hold_revenue'];
            }
        }

        $userCreatedCondition = $rangeCondition('c.created_at', $fromDate, $toDate);
        $userUsedCondition = $rangeCondition('c.qr_used_at', $fromDate, $toDate);
        $userParticipationSources = [
            "SELECT owner_user_id AS user_id, id AS client_id
               FROM clients
              WHERE owner_user_id IS NOT NULL",
        ];
        if (tableExists($db, 'client_user_access')) {
            $userParticipationSources[] = 'SELECT user_id, client_id FROM client_user_access';
        }
        if (tableExists($db, 'client_activity_logs')) {
            $userParticipationSources[] = "SELECT actor_user_id AS user_id, client_id
                                             FROM client_activity_logs
                                            WHERE actor_user_id IS NOT NULL";
        }
        $userClientParticipation = '(' . implode(' UNION ', $userParticipationSources) . ')';
        $userStats = $db->query(
            "SELECT u.id, u.display_name, u.username, u.platform_access,
                    COUNT(DISTINCT CASE WHEN {$userCreatedCondition} THEN c.id END) AS client_count,
                    COUNT(DISTINCT CASE WHEN c.status='cod_folosit' AND {$userUsedCondition} THEN c.id END) AS used_count,
                    COALESCE(SUM(CASE WHEN c.status='cod_folosit' AND {$userUsedCondition}
                                      THEN c.price * (1 - c.discount_percentage/100) ELSE 0 END),0) AS revenue
             FROM app_users u
             LEFT JOIN {$userClientParticipation} participation ON participation.user_id = u.id
             LEFT JOIN clients c ON c.id = participation.client_id
             WHERE u.is_active = 1
             GROUP BY u.id, u.display_name, u.username, u.platform_access
             HAVING client_count > 0 OR used_count > 0 OR revenue > 0
             ORDER BY revenue DESC, client_count DESC
             LIMIT 8"
        )->fetchAll();
        foreach ($userStats as &$userStat) {
            $userStat['clientCount'] = (int)$userStat['client_count'];
            $userStat['usedCount'] = (int)$userStat['used_count'];
            $userStat['revenue'] = (float)$userStat['revenue'];
            unset($userStat['client_count'], $userStat['used_count']);
        }
        unset($userStat);

        $laborExpenses = $scalar(
            $db,
            "SELECT COALESCE(SUM(manopera_colaboratori),0) FROM clients WHERE status='cod_folosit'{$dateWhere}"
        );
        $partsExpenses = $scalar(
            $db,
            "SELECT COALESCE(SUM(valoare_piese),0) FROM clients WHERE status='cod_folosit'{$dateWhere}"
        );
        $customExpenses = $scalar(
            $db,
            "SELECT COALESCE(SUM(alte_cheltuieli),0) FROM clients WHERE status='cod_folosit'{$dateWhere}"
        );

        echo json_encode([
            'totalClients'  => $totalClients,
            'totalRevenue'  => $totalRevenue,
            'onHoldClients' => $onHoldClients,
            'onHoldRevenue' => $onHoldRevenue,
            'qrStats'       => [
                'total'          => $qrTotal,
                'used'           => $qrUsed,
                'generated'      => $qrGenerated,
                'pendingRevenue' => $qrPendingRevenue,
            ],
            'totalExpenses' => $totalExpenses + $totalProfileEarnings,
            'statusCounts'  => $statusCounts,
            'profileStats'  => $profileStats,
            'collaboratorStats' => $collaboratorStats,
            'netProfit'     => $netProfit,
            'previous'      => $previous,
            'series'        => array_values($seriesMap),
            'seriesGranularity' => $seriesGranularity,
            'userStats'     => $userStats,
            'expenseBreakdown' => [
                'labor' => $laborExpenses,
                'parts' => $partsExpenses,
                'custom' => $customExpenses,
                'total' => $laborExpenses + $partsExpenses + $customExpenses,
            ],
            'range' => [
                'from' => $fromDate ? $fromDate->format('Y-m-d') : null,
                'to' => $toDate ? $toDate->modify('-1 day')->format('Y-m-d') : null,
            ],
            'period'        => $period,
        ]);

    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Actiune necunoscuta: ' . $action]);
    }

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
